package cide.gast;

public class NaiveJJPrinter {

}
