package cide.gast;

public interface ISourceFile extends IASTNode {

}
