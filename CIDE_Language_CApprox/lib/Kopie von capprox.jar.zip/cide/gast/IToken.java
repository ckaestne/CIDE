package cide.gast;

public interface IToken {
	public int getOffset();

	public int getLength();
}
