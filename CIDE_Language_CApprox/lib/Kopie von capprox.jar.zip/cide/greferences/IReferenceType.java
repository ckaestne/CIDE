package cide.greferences;

public interface IReferenceType {

}
