package cide.greferences;

public class ReferenceResolvingException extends Exception {
	public ReferenceResolvingException() {
		super();
	}

	public ReferenceResolvingException(String message) {
		super(message);
	}
}
