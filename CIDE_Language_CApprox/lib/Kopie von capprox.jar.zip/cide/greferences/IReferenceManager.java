package cide.greferences;

public interface IReferenceManager {
	public ReferenceType[] getReferenceTypes();
}
