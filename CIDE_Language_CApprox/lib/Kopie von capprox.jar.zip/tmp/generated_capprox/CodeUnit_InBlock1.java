package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_InBlock1 extends CodeUnit_InBlock {
  public CodeUnit_InBlock1(PPIfDef_BlockLevel pPIfDef_BlockLevel, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<PPIfDef_BlockLevel>("pPIfDef_BlockLevel", pPIfDef_BlockLevel)
    }, firstToken, lastToken);
  }
  public CodeUnit_InBlock1(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_InBlock1(cloneProperties(),firstToken,lastToken);
  }
  public PPIfDef_BlockLevel getPPIfDef_BlockLevel() {
    return ((PropertyOne<PPIfDef_BlockLevel>)getProperty("pPIfDef_BlockLevel")).getValue();
  }
}
