package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

abstract class CodeUnit_TopLevel extends GenASTNode {
  protected CodeUnit_TopLevel(Property[] p, Token firstToken, Token lastToken) { super(p, firstToken, lastToken); }
  protected CodeUnit_TopLevel(Property[] p, IToken firstToken, IToken lastToken) { super(p, firstToken, lastToken); }
}
