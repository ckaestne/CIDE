package tmp.generated_capprox;

import java.util.*;
import cide.gast.*;

import java.io.PrintStream;

import cide.languages.*;

public class SimplePrintVisitor extends AbstractPrintVisitor implements ILanguagePrintVisitor {
	public SimplePrintVisitor(PrintStream out) {
		super(out);
	}
	public SimplePrintVisitor() {
		super();
	}
	public boolean visit(ASTNode node) {
		if (node instanceof ASTStringNode){
			printToken(((ASTStringNode)node).getValue());
			return false;
		}
		if (node instanceof ASTTextNode){
			return false;
		}
		if (node instanceof TranslationUnit) {
			TranslationUnit n = (TranslationUnit)node;
			{
				Sequence_CodeUnit_TopLevel v=n.getSequence_CodeUnit_TopLevel();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getEof();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof Sequence_CodeUnit_TopLevel) {
			Sequence_CodeUnit_TopLevel n = (Sequence_CodeUnit_TopLevel)node;
			for (CodeUnit_TopLevel v : n.getCodeUnit_TopLevel()) {
				v.accept(this);
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel1) {
			CodeUnit_TopLevel1 n = (CodeUnit_TopLevel1)node;
			{
				PPIncludeStatement v=n.getPPIncludeStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel2) {
			CodeUnit_TopLevel2 n = (CodeUnit_TopLevel2)node;
			{
				PPDefineStatement v=n.getPPDefineStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel3) {
			CodeUnit_TopLevel3 n = (CodeUnit_TopLevel3)node;
			{
				PPIfDef_TopLevel v=n.getPPIfDef_TopLevel();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel4) {
			CodeUnit_TopLevel4 n = (CodeUnit_TopLevel4)node;
			printToken("#");
			{
				PPOtherIgnore v=n.getPPOtherIgnore();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel5) {
			CodeUnit_TopLevel5 n = (CodeUnit_TopLevel5)node;
			{
				Function v=n.getFunction();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel6) {
			CodeUnit_TopLevel6 n = (CodeUnit_TopLevel6)node;
			{
				TypeDef v=n.getTypeDef();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_TopLevel7) {
			CodeUnit_TopLevel7 n = (CodeUnit_TopLevel7)node;
			{
				Statement v=n.getStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock1) {
			CodeUnit_InBlock1 n = (CodeUnit_InBlock1)node;
			{
				PPIfDef_BlockLevel v=n.getPPIfDef_BlockLevel();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock2) {
			CodeUnit_InBlock2 n = (CodeUnit_InBlock2)node;
			{
				PPDefineStatement v=n.getPPDefineStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock3) {
			CodeUnit_InBlock3 n = (CodeUnit_InBlock3)node;
			printToken("#");
			{
				PPOtherIgnore v=n.getPPOtherIgnore();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock4) {
			CodeUnit_InBlock4 n = (CodeUnit_InBlock4)node;
			{
				IfStatement v=n.getIfStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock5) {
			CodeUnit_InBlock5 n = (CodeUnit_InBlock5)node;
			{
				ForStatement v=n.getForStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock6) {
			CodeUnit_InBlock6 n = (CodeUnit_InBlock6)node;
			{
				WhileStatement v=n.getWhileStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock7) {
			CodeUnit_InBlock7 n = (CodeUnit_InBlock7)node;
			{
				DoStatement v=n.getDoStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock8) {
			CodeUnit_InBlock8 n = (CodeUnit_InBlock8)node;
			{
				SwitchStatement v=n.getSwitchStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock9) {
			CodeUnit_InBlock9 n = (CodeUnit_InBlock9)node;
			{
				GotoLabel v=n.getGotoLabel();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock10) {
			CodeUnit_InBlock10 n = (CodeUnit_InBlock10)node;
			{
				Block v=n.getBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof CodeUnit_InBlock11) {
			CodeUnit_InBlock11 n = (CodeUnit_InBlock11)node;
			{
				Statement v=n.getStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof Statement) {
			Statement n = (Statement)node;
			for (AnyStmtToken v : n.getAnyStmtToken()) {
				v.accept(this);
			}
			printToken(";");
			return false;
		}
		if (node instanceof IfStatement) {
			IfStatement n = (IfStatement)node;
			printToken("if");
			printToken("(");
			{
				ASTStringNode v=n.getFindendcb();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				BlockOrSingleStatement v=n.getBlockOrSingleStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				BlockOrSingleStatement v=n.getBlockOrSingleStatement1();
				if (v!=null) {
					printToken("else");
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof ForStatement) {
			ForStatement n = (ForStatement)node;
			printToken("for");
			printToken("(");
			{
				ASTStringNode v=n.getFindendcb();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				BlockOrSingleStatement v=n.getBlockOrSingleStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof WhileStatement) {
			WhileStatement n = (WhileStatement)node;
			printToken("while");
			printToken("(");
			{
				ASTStringNode v=n.getFindendcb();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				BlockOrSingleStatement v=n.getBlockOrSingleStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof DoStatement) {
			DoStatement n = (DoStatement)node;
			printToken("do");
			{
				BlockOrSingleStatement v=n.getBlockOrSingleStatement();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken("while");
			printToken("(");
			{
				ASTStringNode v=n.getFindendcb();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken(";");
			return false;
		}
		if (node instanceof SwitchStatement) {
			SwitchStatement n = (SwitchStatement)node;
			printToken("switch");
			printToken("(");
			{
				ASTStringNode v=n.getFindendcb();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken("{");
			for (SwCase v : n.getSwCase()) {
				v.accept(this);
			}
			{
				SwDefault v=n.getSwDefault();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken("}");
			return false;
		}
		if (node instanceof SwCase) {
			SwCase n = (SwCase)node;
			printToken("case");
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					printToken("(");
					v.accept(this);
					printToken(")");
				}
			}
			{
				SwCaseLabel v=n.getSwCaseLabel();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken(":");
			{
				Sequence_CodeUnit_InBlock v=n.getSequence_CodeUnit_InBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof SwCaseLabel1) {
			SwCaseLabel1 n = (SwCaseLabel1)node;
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof SwCaseLabel2) {
			SwCaseLabel2 n = (SwCaseLabel2)node;
			{
				ASTStringNode v=n.getLiteral();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof SwDefault) {
			SwDefault n = (SwDefault)node;
			printToken("default");
			printToken(":");
			{
				Sequence_CodeUnit_InBlock v=n.getSequence_CodeUnit_InBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof PPIncludeStatement) {
			PPIncludeStatement n = (PPIncludeStatement)node;
			printToken("#");
			printToken("include");
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof PPDefineStatement1) {
			PPDefineStatement1 n = (PPDefineStatement1)node;
			printToken("#");
			printToken("define");
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof PPDefineStatement2) {
			PPDefineStatement2 n = (PPDefineStatement2)node;
			printToken("#");
			printToken("undef");
			{
				ASTStringNode v=n.getFindlineend1();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof PPIfDef_TopLevel) {
			PPIfDef_TopLevel n = (PPIfDef_TopLevel)node;
			{
				IfDefLine v=n.getIfDefLine();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				Sequence_CodeUnit_TopLevel v=n.getSequence_CodeUnit_TopLevel();
				if (v!=null) {
					v.accept(this);
				}
			}
			for (IfElseIf_TopLevel v : n.getIfElseIf_TopLevel()) {
				v.accept(this);
			}
			{
				Sequence_CodeUnit_TopLevel v=n.getSequence_CodeUnit_TopLevel1();
				if (v!=null) {
					printToken("#");
					printToken("else");
					v.accept(this);
				}
			}
			printToken("#");
			printToken("endif");
			return false;
		}
		if (node instanceof PPIfDef_BlockLevel) {
			PPIfDef_BlockLevel n = (PPIfDef_BlockLevel)node;
			{
				IfDefLine v=n.getIfDefLine();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				Sequence_CodeUnit_InBlock v=n.getSequence_CodeUnit_InBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			for (IfElseIf_BlockLevel v : n.getIfElseIf_BlockLevel()) {
				v.accept(this);
			}
			{
				Sequence_CodeUnit_InBlock v=n.getSequence_CodeUnit_InBlock1();
				if (v!=null) {
					printToken("#");
					printToken("else");
					v.accept(this);
				}
			}
			printToken("#");
			printToken("endif");
			return false;
		}
		if (node instanceof PPOtherIgnore1) {
			PPOtherIgnore1 n = (PPOtherIgnore1)node;
			printToken("line");
			return false;
		}
		if (node instanceof PPOtherIgnore2) {
			PPOtherIgnore2 n = (PPOtherIgnore2)node;
			printToken("pragma");
			return false;
		}
		if (node instanceof PPOtherIgnore3) {
			PPOtherIgnore3 n = (PPOtherIgnore3)node;
			printToken("error");
			return false;
		}
		if (node instanceof IfDefLine1) {
			IfDefLine1 n = (IfDefLine1)node;
			printToken("#");
			printToken("ifdef");
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof IfDefLine2) {
			IfDefLine2 n = (IfDefLine2)node;
			printToken("#");
			printToken("ifndef");
			{
				ASTStringNode v=n.getIdentifier1();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof IfDefLine3) {
			IfDefLine3 n = (IfDefLine3)node;
			printToken("#");
			printToken("if");
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof IfElseIf1) {
			IfElseIf1 n = (IfElseIf1)node;
			printToken("#");
			printToken("elif");
			return false;
		}
		if (node instanceof IfElseIf2) {
			IfElseIf2 n = (IfElseIf2)node;
			printToken("#");
			printToken("elsif");
			return false;
		}
		if (node instanceof IfElseIf_BlockLevel) {
			IfElseIf_BlockLevel n = (IfElseIf_BlockLevel)node;
			{
				IfElseIf v=n.getIfElseIf();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				Sequence_CodeUnit_InBlock v=n.getSequence_CodeUnit_InBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof IfElseIf_TopLevel) {
			IfElseIf_TopLevel n = (IfElseIf_TopLevel)node;
			{
				IfElseIf v=n.getIfElseIf();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getFindlineend();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				Sequence_CodeUnit_TopLevel v=n.getSequence_CodeUnit_TopLevel();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof Function) {
			Function n = (Function)node;
			{
				FunctionHeader v=n.getFunctionHeader();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getFindendcb();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				BlockOrSemi v=n.getBlockOrSemi();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof FunctionHeader) {
			FunctionHeader n = (FunctionHeader)node;
			for (Modifier v : n.getModifier()) {
				v.accept(this);
			}
			{
				FunctionReturnType v=n.getFunctionReturnType();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTTextNode v=n.getText6();
				if (v!=null) {
					printToken("*");
					v.accept(this);
				}
			}
			{
				FunctionExoticStuff v=n.getFunctionExoticStuff();
				if (v!=null) {
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken("(");
			return false;
		}
		if (node instanceof FunctionReturnType) {
			FunctionReturnType n = (FunctionReturnType)node;
			{
				ASTTextNode v=n.getText7();
				if (v!=null) {
					printToken("const");
					v.accept(this);
				}
			}
			{
				ASTTextNode v=n.getText8();
				if (v!=null) {
					printToken("struct");
					v.accept(this);
				}
			}
			{
				ASTTextNode v=n.getText9();
				if (v!=null) {
					printToken("unsigned");
					v.accept(this);
				}
			}
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof Modifier1) {
			Modifier1 n = (Modifier1)node;
			printToken("static");
			return false;
		}
		if (node instanceof Modifier2) {
			Modifier2 n = (Modifier2)node;
			printToken("inline");
			return false;
		}
		if (node instanceof Modifier3) {
			Modifier3 n = (Modifier3)node;
			printToken("__inline__");
			return false;
		}
		if (node instanceof Modifier4) {
			Modifier4 n = (Modifier4)node;
			printToken("extern");
			return false;
		}
		if (node instanceof FunctionExoticStuff) {
			FunctionExoticStuff n = (FunctionExoticStuff)node;
			printToken("__regbank");
			printToken("(");
			{
				ASTStringNode v=n.getLiteral();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken(")");
			return false;
		}
		if (node instanceof Block) {
			Block n = (Block)node;
			printToken("{");
			{
				Sequence_CodeUnit_InBlock v=n.getSequence_CodeUnit_InBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken("}");
			return false;
		}
		if (node instanceof GotoLabel) {
			GotoLabel n = (GotoLabel)node;
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken(":");
			return false;
		}
		if (node instanceof Sequence_CodeUnit_InBlock) {
			Sequence_CodeUnit_InBlock n = (Sequence_CodeUnit_InBlock)node;
			for (CodeUnit_InBlock v : n.getCodeUnit_InBlock()) {
				v.accept(this);
			}
			return false;
		}
		if (node instanceof BlockOrSemi1) {
			BlockOrSemi1 n = (BlockOrSemi1)node;
			printToken(";");
			return false;
		}
		if (node instanceof BlockOrSemi2) {
			BlockOrSemi2 n = (BlockOrSemi2)node;
			{
				Block v=n.getBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof BlockOrSingleStatement1) {
			BlockOrSingleStatement1 n = (BlockOrSingleStatement1)node;
			{
				Block v=n.getBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof BlockOrSingleStatement2) {
			BlockOrSingleStatement2 n = (BlockOrSingleStatement2)node;
			{
				CodeUnit_InBlock v=n.getCodeUnit_InBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof TypeDef1) {
			TypeDef1 n = (TypeDef1)node;
			printToken("typedef");
			printToken("enum");
			for (AnyTypeDefToken v : n.getAnyTypeDefToken()) {
				v.accept(this);
			}
			printToken(";");
			return false;
		}
		if (node instanceof TypeDef2) {
			TypeDef2 n = (TypeDef2)node;
			printToken("typedef");
			for (AnyStmtToken v : n.getAnyStmtToken()) {
				v.accept(this);
			}
			printToken(";");
			return false;
		}
		if (node instanceof BlockAssignment) {
			BlockAssignment n = (BlockAssignment)node;
			printToken("=");
			{
				Cast v=n.getCast();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken("{");
			{
				ASTStringNode v=n.getFindendccb();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof EnumBlock) {
			EnumBlock n = (EnumBlock)node;
			printToken("enum");
			printToken("{");
			{
				ASTStringNode v=n.getFindendccb();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof Cast) {
			Cast n = (Cast)node;
			printToken("(");
			{
				FunctionReturnType v=n.getFunctionReturnType();
				if (v!=null) {
					v.accept(this);
				}
			}
			printToken(")");
			return false;
		}
		if (node instanceof AnyTypeDefToken1) {
			AnyTypeDefToken1 n = (AnyTypeDefToken1)node;
			printToken("{");
			return false;
		}
		if (node instanceof AnyTypeDefToken2) {
			AnyTypeDefToken2 n = (AnyTypeDefToken2)node;
			printToken("}");
			return false;
		}
		if (node instanceof AnyTypeDefToken3) {
			AnyTypeDefToken3 n = (AnyTypeDefToken3)node;
			{
				AnyStmtToken v=n.getAnyStmtToken();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken1) {
			AnyStmtToken1 n = (AnyStmtToken1)node;
			{
				ASTStringNode v=n.getIdentifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken2) {
			AnyStmtToken2 n = (AnyStmtToken2)node;
			{
				ASTStringNode v=n.getLiteral();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken3) {
			AnyStmtToken3 n = (AnyStmtToken3)node;
			{
				ASTStringNode v=n.getOther();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken4) {
			AnyStmtToken4 n = (AnyStmtToken4)node;
			printToken("<");
			return false;
		}
		if (node instanceof AnyStmtToken5) {
			AnyStmtToken5 n = (AnyStmtToken5)node;
			printToken(">");
			return false;
		}
		if (node instanceof AnyStmtToken6) {
			AnyStmtToken6 n = (AnyStmtToken6)node;
			printToken("(");
			return false;
		}
		if (node instanceof AnyStmtToken7) {
			AnyStmtToken7 n = (AnyStmtToken7)node;
			printToken(")");
			return false;
		}
		if (node instanceof AnyStmtToken8) {
			AnyStmtToken8 n = (AnyStmtToken8)node;
			{
				Block v=n.getBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken9) {
			AnyStmtToken9 n = (AnyStmtToken9)node;
			printToken("if");
			return false;
		}
		if (node instanceof AnyStmtToken10) {
			AnyStmtToken10 n = (AnyStmtToken10)node;
			printToken("else");
			return false;
		}
		if (node instanceof AnyStmtToken11) {
			AnyStmtToken11 n = (AnyStmtToken11)node;
			printToken("for");
			return false;
		}
		if (node instanceof AnyStmtToken12) {
			AnyStmtToken12 n = (AnyStmtToken12)node;
			printToken("while");
			return false;
		}
		if (node instanceof AnyStmtToken13) {
			AnyStmtToken13 n = (AnyStmtToken13)node;
			{
				EnumBlock v=n.getEnumBlock();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken14) {
			AnyStmtToken14 n = (AnyStmtToken14)node;
			printToken("enum");
			return false;
		}
		if (node instanceof AnyStmtToken15) {
			AnyStmtToken15 n = (AnyStmtToken15)node;
			printToken("*");
			return false;
		}
		if (node instanceof AnyStmtToken16) {
			AnyStmtToken16 n = (AnyStmtToken16)node;
			{
				BlockAssignment v=n.getBlockAssignment();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken17) {
			AnyStmtToken17 n = (AnyStmtToken17)node;
			printToken("=");
			return false;
		}
		if (node instanceof AnyStmtToken18) {
			AnyStmtToken18 n = (AnyStmtToken18)node;
			printToken(":");
			return false;
		}
		if (node instanceof AnyStmtToken19) {
			AnyStmtToken19 n = (AnyStmtToken19)node;
			{
				Modifier v=n.getModifier();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken20) {
			AnyStmtToken20 n = (AnyStmtToken20)node;
			printToken("ifdef");
			return false;
		}
		if (node instanceof AnyStmtToken21) {
			AnyStmtToken21 n = (AnyStmtToken21)node;
			printToken("ifndef");
			return false;
		}
		if (node instanceof AnyStmtToken22) {
			AnyStmtToken22 n = (AnyStmtToken22)node;
			printToken("define");
			return false;
		}
		if (node instanceof AnyStmtToken23) {
			AnyStmtToken23 n = (AnyStmtToken23)node;
			printToken("include");
			return false;
		}
		if (node instanceof AnyStmtToken24) {
			AnyStmtToken24 n = (AnyStmtToken24)node;
			printToken("elif");
			return false;
		}
		if (node instanceof AnyStmtToken25) {
			AnyStmtToken25 n = (AnyStmtToken25)node;
			printToken("elsif");
			return false;
		}
		if (node instanceof AnyStmtToken26) {
			AnyStmtToken26 n = (AnyStmtToken26)node;
			{
				PPOtherIgnore v=n.getPPOtherIgnore();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		if (node instanceof AnyStmtToken27) {
			AnyStmtToken27 n = (AnyStmtToken27)node;
			printToken("const");
			return false;
		}
		if (node instanceof AnyStmtToken28) {
			AnyStmtToken28 n = (AnyStmtToken28)node;
			printToken("struct");
			return false;
		}
		if (node instanceof AnyStmtToken29) {
			AnyStmtToken29 n = (AnyStmtToken29)node;
			printToken("unsigned");
			return false;
		}
		if (node instanceof Literal) {
			Literal n = (Literal)node;
			{
				ASTStringNode v=n.getLiteral();
				if (v!=null) {
					v.accept(this);
				}
			}
			return false;
		}
		return true;
	}
}
