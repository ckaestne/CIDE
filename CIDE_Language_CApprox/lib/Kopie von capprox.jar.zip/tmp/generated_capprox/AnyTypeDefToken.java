package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

abstract class AnyTypeDefToken extends GenASTNode {
  protected AnyTypeDefToken(Property[] p, Token firstToken, Token lastToken) { super(p, firstToken, lastToken); }
  protected AnyTypeDefToken(Property[] p, IToken firstToken, IToken lastToken) { super(p, firstToken, lastToken); }
}
