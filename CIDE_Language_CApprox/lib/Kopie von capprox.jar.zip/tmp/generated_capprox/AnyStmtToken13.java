package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class AnyStmtToken13 extends AnyStmtToken {
  public AnyStmtToken13(EnumBlock enumBlock, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<EnumBlock>("enumBlock", enumBlock)
    }, firstToken, lastToken);
  }
  public AnyStmtToken13(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new AnyStmtToken13(cloneProperties(),firstToken,lastToken);
  }
  public EnumBlock getEnumBlock() {
    return ((PropertyOne<EnumBlock>)getProperty("enumBlock")).getValue();
  }
}
