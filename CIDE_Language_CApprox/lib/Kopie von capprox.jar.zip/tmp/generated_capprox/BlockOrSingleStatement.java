package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

abstract class BlockOrSingleStatement extends GenASTNode {
  protected BlockOrSingleStatement(Property[] p, Token firstToken, Token lastToken) { super(p, firstToken, lastToken); }
  protected BlockOrSingleStatement(Property[] p, IToken firstToken, IToken lastToken) { super(p, firstToken, lastToken); }
}
