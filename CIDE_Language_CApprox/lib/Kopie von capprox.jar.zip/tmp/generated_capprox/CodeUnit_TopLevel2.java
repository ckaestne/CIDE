package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_TopLevel2 extends CodeUnit_TopLevel {
  public CodeUnit_TopLevel2(PPDefineStatement pPDefineStatement, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<PPDefineStatement>("pPDefineStatement", pPDefineStatement)
    }, firstToken, lastToken);
  }
  public CodeUnit_TopLevel2(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_TopLevel2(cloneProperties(),firstToken,lastToken);
  }
  public PPDefineStatement getPPDefineStatement() {
    return ((PropertyOne<PPDefineStatement>)getProperty("pPDefineStatement")).getValue();
  }
}
