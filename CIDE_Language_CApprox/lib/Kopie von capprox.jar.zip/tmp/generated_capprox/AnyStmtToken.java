package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

abstract class AnyStmtToken extends GenASTNode {
  protected AnyStmtToken(Property[] p, Token firstToken, Token lastToken) { super(p, firstToken, lastToken); }
  protected AnyStmtToken(Property[] p, IToken firstToken, IToken lastToken) { super(p, firstToken, lastToken); }
}
