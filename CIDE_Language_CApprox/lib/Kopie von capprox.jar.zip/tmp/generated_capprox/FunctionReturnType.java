package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class FunctionReturnType extends GenASTNode {
  public FunctionReturnType(ASTTextNode text7, ASTTextNode text8, ASTTextNode text9, ASTStringNode identifier, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyZeroOrOne<ASTTextNode>("text7", text7),
      new PropertyZeroOrOne<ASTTextNode>("text8", text8),
      new PropertyZeroOrOne<ASTTextNode>("text9", text9),
      new PropertyOne<ASTStringNode>("identifier", identifier)
    }, firstToken, lastToken);
  }
  public FunctionReturnType(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new FunctionReturnType(cloneProperties(),firstToken,lastToken);
  }
  public ASTTextNode getText7() {
    return ((PropertyZeroOrOne<ASTTextNode>)getProperty("text7")).getValue();
  }
  public ASTTextNode getText8() {
    return ((PropertyZeroOrOne<ASTTextNode>)getProperty("text8")).getValue();
  }
  public ASTTextNode getText9() {
    return ((PropertyZeroOrOne<ASTTextNode>)getProperty("text9")).getValue();
  }
  public ASTStringNode getIdentifier() {
    return ((PropertyOne<ASTStringNode>)getProperty("identifier")).getValue();
  }
}
