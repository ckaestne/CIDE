package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

abstract class IfElseIf extends GenASTNode {
  protected IfElseIf(Property[] p, Token firstToken, Token lastToken) { super(p, firstToken, lastToken); }
  protected IfElseIf(Property[] p, IToken firstToken, IToken lastToken) { super(p, firstToken, lastToken); }
}
