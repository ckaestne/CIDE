package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_TopLevel3 extends CodeUnit_TopLevel {
  public CodeUnit_TopLevel3(PPIfDef_TopLevel pPIfDef_TopLevel, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<PPIfDef_TopLevel>("pPIfDef_TopLevel", pPIfDef_TopLevel)
    }, firstToken, lastToken);
  }
  public CodeUnit_TopLevel3(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_TopLevel3(cloneProperties(),firstToken,lastToken);
  }
  public PPIfDef_TopLevel getPPIfDef_TopLevel() {
    return ((PropertyOne<PPIfDef_TopLevel>)getProperty("pPIfDef_TopLevel")).getValue();
  }
}
