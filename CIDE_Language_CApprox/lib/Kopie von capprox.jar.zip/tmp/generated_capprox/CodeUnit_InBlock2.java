package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_InBlock2 extends CodeUnit_InBlock {
  public CodeUnit_InBlock2(PPDefineStatement pPDefineStatement, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<PPDefineStatement>("pPDefineStatement", pPDefineStatement)
    }, firstToken, lastToken);
  }
  public CodeUnit_InBlock2(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_InBlock2(cloneProperties(),firstToken,lastToken);
  }
  public PPDefineStatement getPPDefineStatement() {
    return ((PropertyOne<PPDefineStatement>)getProperty("pPDefineStatement")).getValue();
  }
}
