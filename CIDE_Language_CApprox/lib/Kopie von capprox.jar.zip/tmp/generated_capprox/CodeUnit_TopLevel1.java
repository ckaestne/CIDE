package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_TopLevel1 extends CodeUnit_TopLevel {
  public CodeUnit_TopLevel1(PPIncludeStatement pPIncludeStatement, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<PPIncludeStatement>("pPIncludeStatement", pPIncludeStatement)
    }, firstToken, lastToken);
  }
  public CodeUnit_TopLevel1(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_TopLevel1(cloneProperties(),firstToken,lastToken);
  }
  public PPIncludeStatement getPPIncludeStatement() {
    return ((PropertyOne<PPIncludeStatement>)getProperty("pPIncludeStatement")).getValue();
  }
}
