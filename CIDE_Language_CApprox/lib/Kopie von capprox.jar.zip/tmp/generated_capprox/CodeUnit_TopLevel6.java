package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_TopLevel6 extends CodeUnit_TopLevel {
  public CodeUnit_TopLevel6(TypeDef typeDef, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<TypeDef>("typeDef", typeDef)
    }, firstToken, lastToken);
  }
  public CodeUnit_TopLevel6(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_TopLevel6(cloneProperties(),firstToken,lastToken);
  }
  public TypeDef getTypeDef() {
    return ((PropertyOne<TypeDef>)getProperty("typeDef")).getValue();
  }
}
