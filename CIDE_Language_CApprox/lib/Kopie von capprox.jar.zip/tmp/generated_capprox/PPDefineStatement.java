package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

abstract class PPDefineStatement extends GenASTNode {
  protected PPDefineStatement(Property[] p, Token firstToken, Token lastToken) { super(p, firstToken, lastToken); }
  protected PPDefineStatement(Property[] p, IToken firstToken, IToken lastToken) { super(p, firstToken, lastToken); }
}
