package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_InBlock5 extends CodeUnit_InBlock {
  public CodeUnit_InBlock5(ForStatement forStatement, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<ForStatement>("forStatement", forStatement)
    }, firstToken, lastToken);
  }
  public CodeUnit_InBlock5(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_InBlock5(cloneProperties(),firstToken,lastToken);
  }
  public ForStatement getForStatement() {
    return ((PropertyOne<ForStatement>)getProperty("forStatement")).getValue();
  }
}
