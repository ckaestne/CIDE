package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_InBlock6 extends CodeUnit_InBlock {
  public CodeUnit_InBlock6(WhileStatement whileStatement, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<WhileStatement>("whileStatement", whileStatement)
    }, firstToken, lastToken);
  }
  public CodeUnit_InBlock6(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_InBlock6(cloneProperties(),firstToken,lastToken);
  }
  public WhileStatement getWhileStatement() {
    return ((PropertyOne<WhileStatement>)getProperty("whileStatement")).getValue();
  }
}
