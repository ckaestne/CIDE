package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class CodeUnit_InBlock7 extends CodeUnit_InBlock {
  public CodeUnit_InBlock7(DoStatement doStatement, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<DoStatement>("doStatement", doStatement)
    }, firstToken, lastToken);
  }
  public CodeUnit_InBlock7(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new CodeUnit_InBlock7(cloneProperties(),firstToken,lastToken);
  }
  public DoStatement getDoStatement() {
    return ((PropertyOne<DoStatement>)getProperty("doStatement")).getValue();
  }
}
