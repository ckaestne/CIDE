package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class Function extends GenASTNode {
  public Function(FunctionHeader functionHeader, ASTStringNode findendcb, BlockOrSemi blockOrSemi, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<FunctionHeader>("functionHeader", functionHeader),
      new PropertyOne<ASTStringNode>("findendcb", findendcb),
      new PropertyOne<BlockOrSemi>("blockOrSemi", blockOrSemi)
    }, firstToken, lastToken);
  }
  public Function(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new Function(cloneProperties(),firstToken,lastToken);
  }
  public FunctionHeader getFunctionHeader() {
    return ((PropertyOne<FunctionHeader>)getProperty("functionHeader")).getValue();
  }
  public ASTStringNode getFindendcb() {
    return ((PropertyOne<ASTStringNode>)getProperty("findendcb")).getValue();
  }
  public BlockOrSemi getBlockOrSemi() {
    return ((PropertyOne<BlockOrSemi>)getProperty("blockOrSemi")).getValue();
  }
}
