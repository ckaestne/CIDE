package tmp.generated_capprox;

import java.util.*;
import cide.greferences.*;

import cide.gast.*;

public class ReferenceManager implements IReferenceManager {
	
	public ReferenceType[] getReferenceTypes() {
		return new ReferenceType[] {  };
	}
}
