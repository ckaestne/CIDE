package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class PPOtherIgnore1 extends PPOtherIgnore {
  public PPOtherIgnore1(Token firstToken, Token lastToken) {
    super(new Property[] {
    }, firstToken, lastToken);
  }
  public PPOtherIgnore1(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new PPOtherIgnore1(cloneProperties(),firstToken,lastToken);
  }
}
