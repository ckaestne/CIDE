package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class IfStatement extends GenASTNode {
  public IfStatement(ASTStringNode findendcb, BlockOrSingleStatement blockOrSingleStatement, BlockOrSingleStatement blockOrSingleStatement1, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<ASTStringNode>("findendcb", findendcb),
      new PropertyOne<BlockOrSingleStatement>("blockOrSingleStatement", blockOrSingleStatement),
      new PropertyZeroOrOne<BlockOrSingleStatement>("blockOrSingleStatement1", blockOrSingleStatement1)
    }, firstToken, lastToken);
  }
  public IfStatement(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new IfStatement(cloneProperties(),firstToken,lastToken);
  }
  public ASTStringNode getFindendcb() {
    return ((PropertyOne<ASTStringNode>)getProperty("findendcb")).getValue();
  }
  public BlockOrSingleStatement getBlockOrSingleStatement() {
    return ((PropertyOne<BlockOrSingleStatement>)getProperty("blockOrSingleStatement")).getValue();
  }
  public BlockOrSingleStatement getBlockOrSingleStatement1() {
    return ((PropertyZeroOrOne<BlockOrSingleStatement>)getProperty("blockOrSingleStatement1")).getValue();
  }
}
