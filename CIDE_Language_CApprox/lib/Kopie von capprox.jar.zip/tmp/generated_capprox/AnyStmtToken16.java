package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class AnyStmtToken16 extends AnyStmtToken {
  public AnyStmtToken16(BlockAssignment blockAssignment, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<BlockAssignment>("blockAssignment", blockAssignment)
    }, firstToken, lastToken);
  }
  public AnyStmtToken16(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new AnyStmtToken16(cloneProperties(),firstToken,lastToken);
  }
  public BlockAssignment getBlockAssignment() {
    return ((PropertyOne<BlockAssignment>)getProperty("blockAssignment")).getValue();
  }
}
