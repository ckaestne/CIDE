package tmp.generated_capprox;

import cide.gast.*;
import cide.gparser.*;
import cide.greferences.*;
import java.util.*;

public class AnyStmtToken19 extends AnyStmtToken {
  public AnyStmtToken19(Modifier modifier, Token firstToken, Token lastToken) {
    super(new Property[] {
      new PropertyOne<Modifier>("modifier", modifier)
    }, firstToken, lastToken);
  }
  public AnyStmtToken19(Property[] properties, IToken firstToken, IToken lastToken) {
    super(properties,firstToken,lastToken);
  }
  public ASTNode deepCopy() {
    return new AnyStmtToken19(cloneProperties(),firstToken,lastToken);
  }
  public Modifier getModifier() {
    return ((PropertyOne<Modifier>)getProperty("modifier")).getValue();
  }
}
