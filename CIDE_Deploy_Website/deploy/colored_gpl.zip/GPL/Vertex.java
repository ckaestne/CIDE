import java.util.LinkedList;

public class Vertex {
	public LinkedList neighbors;

	public String name;

	public Vertex() {
		name = null;
		neighbors = new LinkedList();
		visited = false;
	}

	public Vertex assignName(String name) {
		this.name = name;
		return (Vertex) this;
	}

	public void addNeighbor(Neighbor n) {
		neighbors.add(n);
	}

	public boolean visited;

	public void init_vertex(WorkSpace w) {
		visited = false;
		w.init_vertex(this);
	}

	public void dftNodeSearch(WorkSpace w) {
		int s, c;
		Vertex v;
		Neighbor n;

		// Step 1: Do preVisitAction.
		// If we've already visited this node return

		w.preVisitAction((Vertex) this);

		if (visited)
			return;

		// Step 2: else remember that we've visited and
		// visit all neighbors

		visited = true;

		s = neighbors.size();
		for (c = 0; c < s; c++) {
			n = (Neighbor) neighbors.get(c);
			v = n.end;
			w.checkNeighborAction((Vertex) this, v);
			v.dftNodeSearch(w);
		}
		;

		// Step 3: do postVisitAction now
		w.postVisitAction((Vertex) this);
	} // of dftNodeSearch

	public static LinkedList Queue = new LinkedList();

	public void bftNodeSearch(WorkSpace w) {
		int s, c;
		Vertex v;
		Vertex header;
		Neighbor n;

		// Step 1: if preVisitAction is true or if we've already
		// visited this node

		w.preVisitAction((Vertex) this);

		if (visited)
			return;

		// Step 2: Mark as visited, put the unvisited neighbors in the queue
		// and make the recursive call on the first element of the queue
		// if there is such if not you are done

		visited = true;

		// Step 3: do postVisitAction now, you are no longer going through the
		// node again, mark it as black
		w.postVisitAction((Vertex) this);

		s = neighbors.size();

		// enqueues the vertices not visited
		for (c = 0; c < s; c++) {
			n = (Neighbor) neighbors.get(c);
			v = n.end;

			// if your neighbor has not been visited then enqueue
			if (!v.visited) {
				Queue.add(v);
			}

		} // end of for

		// while there is something in the queue
		while (Queue.size() != 0) {
			header = (Vertex) Queue.get(0);
			Queue.remove(0);
			header.bftNodeSearch(w);
		}

	} // of bfsNodeSearch

	public void display() {
		// TODO fix colors
		// StronglyConnected
		System.out.print(" FinishTime -> " + finishTime + " SCCNo -> "
				+ strongComponentNumber);
		// Shortest
		System.out.print(" Pred " + predecessor + " DWeight " + dweight + " ");
		// Number
		System.out.print(" # " + VertexNumber + " ");
		// MSTPrim
		System.out.print(" Pred " + pred + " Key " + key + " ");
		// MSTKruskal
		if (representative == null)
			System.out.print("Rep null ");
		else
			System.out.print(" Rep " + representative.name + " ");
		// Cycle
		System.out.print(" VertexCycle# " + VertexCycle + " ");
		// Connected
		System.out.print(" comp# " + componentNumber + " ");
		// SearchBase
		if (visited)
			System.out.print("  visited");
		else
			System.out.print(" !visited");

		int s = neighbors.size();
		int i;

		System.out.print(" Node " + name + " connected to: ");

		for (i = 0; i < s; i++) {
			Neighbor theNeighbor = (Neighbor) neighbors.get(i);
			System.out.print(theNeighbor.end.name + ", ");
		}
		System.out.println();
	}

	public int componentNumber;

	public int VertexCycle;

	public int VertexColor; // white ->0, gray ->1, black->2

	public Vertex representative;

	public LinkedList members;

	public String pred; // the predecessor vertex if any

	public int key; // weight so far from s to it

	public int VertexNumber;

	public String predecessor; // the name of the predecessor if any

	public int dweight; // weight so far from s to it

	public int finishTime;

	public int strongComponentNumber;

}
