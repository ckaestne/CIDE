public class Edge {
	public Vertex start;

	public Vertex end;

	public int weight;

	public Edge(Vertex the_start, Vertex the_end) {
		start = the_start;
		end = the_end;
	}

	public Edge(Vertex the_start, Vertex the_end, int the_weight) {
		this(the_start, the_end);
		weight = the_weight;
	}

	public void adjustAdorns(Edge the_edge) {
		weight = the_edge.weight;
	}

	public void display() {
		System.out.print(" Weight=" + weight);
		System.out.println(" start=" + start.name + " end=" + end.name);
	}
}
