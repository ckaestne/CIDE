import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class Graph {
	public LinkedList vertices;

	public LinkedList edges;

	public static final boolean isDirected = true || false;

	public Graph() {
		vertices = new LinkedList();
		edges = new LinkedList();
	}

	// Fall back method that stops the execution of programs
	public void run(Vertex s) {
		// TODO fix colors
		// StronglyConnected
		Graph gaux4 = StrongComponents();
		Graph.stopProfile();
		gaux4.display();
		Graph.resumeProfile();
		// Shortest
		Graph gaux3 = ShortestPath(s);
		Graph.stopProfile();
		gaux3.display();
		Graph.resumeProfile();
		// Number
		NumberVertices();
		// MSTPrim
		Graph gaux = Prim(s);
		Graph.stopProfile();
		gaux.display();
		Graph.resumeProfile();
		// MSTKruskal
		Graph gaux2 = Kruskal();
		Graph.stopProfile();
		gaux2.display();
		Graph.resumeProfile();
		// Cycle
		System.out.println(" Cycle? " + CycleCheck());
		// Connected
		ConnectedComponents();
	}

	public void ConnectedComponents() {
		GraphSearch(new RegionWorkSpace());
	}

	public boolean CycleCheck() {
		CycleWorkSpace c = new CycleWorkSpace(isDirected);
		GraphSearch(c);
		return c.AnyCycles;
	}

	// Adds an edge without weights if Weighted layer is not present
	public void addAnEdge(Vertex start, Vertex end, int weight) {
		if (true)
			addEdge(new Edge(start, end, weight));
		else
			addEdge(new Edge(start, end));
	}

	public void addVertex(Vertex v) {
		vertices.add(v);
	}

	public void addEdge(Edge the_edge) {
		Vertex start = the_edge.start;
		Vertex end = the_edge.end;
		edges.add(the_edge);
		start.addNeighbor(new Neighbor(end, the_edge));
		end.addNeighbor(new Neighbor(start, the_edge));
	}

	// This method adds only the edge and not the neighbor.
	// Used in Transpose layer.
	public void addOnlyEdge(Edge the_edge) {
		edges.add(the_edge);
	}

	// Finds a vertex given its name in the vertices list
	public Vertex findsVertex(String theName) {
		int i = 0;
		Vertex theVertex;

		// if we are dealing with the root
		if (theName == null)
			return null;

		for (i = 0; i < vertices.size(); i++) {
			theVertex = (Vertex) vertices.get(i);
			if (theName.equals(theVertex.name))
				return theVertex;
		}
		return null;
	}

	// Finds an Edge given both of its vertices
	public Edge findsEdge(Vertex theSource, Vertex theTarget) {
		int i = 0;
		Edge theEdge;

		for (i = 0; i < edges.size(); i++) {
			theEdge = (Edge) edges.get(i);
			if ((theEdge.start.name.equals(theSource.name) && theEdge.end.name
					.equals(theTarget.name))
					|| (theEdge.start.name.equals(theTarget.name) && theEdge.end.name
							.equals(theSource.name)))
				return theEdge;
		}
		return null;
	}

	public void display() {
		int i;

		System.out.println("******************************************");
		System.out.println("Vertices ");
		for (i = 0; i < vertices.size(); i++)
			((Vertex) vertices.get(i)).display();

		System.out.println("******************************************");
		System.out.println("Edges ");
		for (i = 0; i < edges.size(); i++)
			((Edge) edges.get(i)).display();

		System.out.println("******************************************");

	}

	public Graph ComputeTranspose(Graph the_graph) {
		int i;
		int num_vertices = (the_graph.vertices).size();
		String theName;

		// Creating the new Graph
		Graph newGraph = new Graph();

		// Creates and adds the vertices with the same name
		for (i = 0; i < num_vertices; i++) {
			theName = ((Vertex) (the_graph.vertices).get(i)).name;
			newGraph.addVertex(new Vertex().assignName(theName));
		}

		Neighbor newNeighbor;
		Vertex theVertex, newVertex;
		Neighbor theNeighbor;
		Vertex newAdjacent;
		Edge newEdge;
		int num_neighbors;
		int j;

		// adds the transposed edges
		for (i = 0; i < num_vertices; i++) {
			// theVertex is the original source vertex
			// the newAdjacent is the reference in the newGraph to theVertex
			theVertex = (Vertex) (the_graph.vertices).get(i);
			newAdjacent = newGraph.findsVertex(theVertex.name);
			num_neighbors = (theVertex.neighbors).size();

			for (j = 0; j < num_neighbors; j++) {
				// Gets the neighbor object in pos j
				theNeighbor = (Neighbor) (theVertex.neighbors).get(j);

				// the new Vertex is the vertex that was adjacent to theVertex
				// but now in the new graph
				newVertex = newGraph.findsVertex(theNeighbor.end.name);

				// Creates a new Edge object and adjusts the adornments
				newEdge = new Edge(newVertex, newAdjacent);
				newEdge.adjustAdorns(theNeighbor.edge);

				// Adds the new Neighbor object with the newly formed edge
				// newNeighbor = new Neighbor(newAdjacent, newEdge);
				// (newVertex.neighbors).add(newNeighbor);

				newGraph.addEdge(newEdge);

			} // all adjacentNeighbors
		} // all the vertices

		return newGraph;

	} // of ComputeTranspose

	// Graph search receives a Working Space, and
	public void GraphSearch(WorkSpace w) {
		int s, c;
		Vertex v;

		// Step 1: initialize visited member of all nodes

		s = vertices.size();
		if (s == 0)
			return; // if there are no vertices return

		// Initializig the vertices
		for (c = 0; c < s; c++) {
			v = (Vertex) vertices.get(c);
			v.init_vertex(w);
		}

		// Step 2: traverse neighbors of each node
		for (c = 0; c < s; c++) {
			v = (Vertex) vertices.get(c);
			if (!v.visited) {
				w.nextRegionAction(v);
				v.dftNodeSearch(w);
				v.bftNodeSearch(w);
			}
		} // end for
	}

	public Graph Kruskal() {

		// 1. A <- Empty set
		LinkedList A = new LinkedList();

		// 2. for each vertex v E V[G]
		// 3. do Make-Set(v)
		int numvertices = vertices.size();
		int i;
		Vertex v;

		for (i = 0; i < numvertices; i++) {
			v = (Vertex) vertices.get(i);
			v.representative = v; // I am in my set
			v.members = new LinkedList(); // I have no members in my set
		}

		// 4. sort the edges of E by nondecreasing weight w
		// Creates the edges objects
		int j;
		LinkedList Vneighbors = new LinkedList();
		Vertex u;

		// Sort the Edges in non decreasing order
		Collections.sort(edges, new Comparator() {
			public int compare(Object o1, Object o2) {
				Edge e1 = (Edge) o1;
				Edge e2 = (Edge) o2;
				if (e1.weight < e2.weight)
					return -1;
				if (e1.weight == e2.weight)
					return 0;
				return 1;
			}
		});

		// 5. for each edge in the nondecresing order
		int numedges = edges.size();
		Edge e1;
		Vertex vaux, urep, vrep;

		for (i = 0; i < numedges; i++) {
			// 6. if Find-Set(u)!=Find-Set(v)
			e1 = (Edge) edges.get(i);
			u = e1.start;
			v = e1.end;

			if (!(v.representative.name).equals(u.representative.name)) {
				// 7. A <- A U {(u,v)}
				A.add(e1);

				// 8. Union(u,v)
				urep = u.representative;
				vrep = v.representative;

				if ((urep.members).size() > (vrep.members).size()) { // we
					// add
					// elements
					// of v
					// to u
					for (j = 0; j < (vrep.members).size(); j++) {
						vaux = (Vertex) (vrep.members).get(j);
						vaux.representative = urep;
						(urep.members).add(vaux);
					}
					v.representative = urep;
					vrep.representative = urep;
					(urep.members).add(v);
					if (!v.equals(vrep))
						(urep.members).add(vrep);
					(vrep.members).clear();
				} else { // we add elements of u to v
					for (j = 0; j < (urep.members).size(); j++) {
						vaux = (Vertex) (urep.members).get(j);
						vaux.representative = vrep;
						(vrep.members).add(vaux);
					}
					u.representative = vrep;
					urep.representative = vrep;
					(vrep.members).add(u);
					if (!u.equals(urep))
						(vrep.members).add(urep);
					(urep.members).clear();

				} // else

			} // of if

		} // of for numedges

		// 9. return A
		// Creates the new Graph that contains the SSSP
		String theName;
		Graph newGraph = new Graph();

		// Creates and adds the vertices with the same name
		for (i = 0; i < numvertices; i++) {
			theName = ((Vertex) vertices.get(i)).name;
			newGraph.addVertex(new Vertex().assignName(theName));
		}

		// Creates the edges from the NewGraph
		Vertex theStart, theEnd;
		Vertex theNewStart, theNewEnd;
		Edge theEdge;

		// For each edge in A we find its two vertices
		// make an edge for the new graph from with the correspoding
		// new two vertices
		for (i = 0; i < A.size(); i++) {
			// theEdge with its two vertices
			theEdge = (Edge) A.get(i);
			theStart = theEdge.start;
			theEnd = theEdge.end;

			// Find the references in the new Graph
			theNewStart = newGraph.findsVertex(theStart.name);
			theNewEnd = newGraph.findsVertex(theEnd.name);

			// Creates the new edge with new start and end vertices in the
			// newGraph
			// and ajusts the adorns based on the old edge
			Edge theNewEdge = new Edge(theNewStart, theNewEnd);
			theNewEdge.adjustAdorns(theEdge);

			// Adds the new edge to the newGraph
			newGraph.addEdge(theNewEdge);
		}
		return newGraph;

	} // kruskal

	public Graph Prim(Vertex r) {
		Vertex root;

		root = r;
		int numvertices = vertices.size();
		int i;
		Vertex x;

		// 2. and 3. Initializes the vertices
		for (i = 0; i < numvertices; i++) {
			x = (Vertex) vertices.get(i);
			x.pred = null;
			x.key = Integer.MAX_VALUE;
		}

		// 4. and 5.
		root.key = 0;
		root.pred = null;

		// 2. S <- empty set

		// 1. Queue <- V[G], copy the vertex in the graph in the priority queue
		LinkedList Queue = new LinkedList();

		for (i = 0; i < numvertices; i++) {
			x = (Vertex) vertices.get(i);
			if (x.key != 0) // this means, if this is not the root
				Queue.add(x);
		}

		// Inserts the root at the head of the queue
		Queue.addFirst(root);

		// 6. while Q!=0
		Vertex ucurrent;
		int j, k, l;
		int pos;
		LinkedList Uneighbors;
		Vertex u, v;
		Edge en;
		Neighbor vn;

		int wuv;
		boolean isNeighborInQueue = false;

		// Queue is a list ordered by key values.
		// At the beginning all key values are INFINITUM except
		// for the root whose value is 0.
		while (Queue.size() != 0) {
			// 7. u <- Extract-Min(Q);
			// Since this is an ordered queue the first element is the min
			u = (Vertex) Queue.removeFirst();

			// 8. for each vertex v adjacent to u
			Uneighbors = u.neighbors;

			for (k = 0; k < Uneighbors.size(); k++) {
				vn = (Neighbor) Uneighbors.get(k);
				v = vn.end;
				en = vn.edge;

				// Check to see if the neighbor is in the queue
				isNeighborInQueue = false;

				// if the Neighor is in the queue
				int indexNeighbor = Queue.indexOf(v);
				if (indexNeighbor >= 0)
					isNeighborInQueue = true;

				wuv = en.weight;

				// 9. Relax (u,v w)
				if (isNeighborInQueue && (wuv < v.key)) {
					v.key = wuv;
					v.pred = u.name;
					Uneighbors.set(k, vn); // adjust values in the neighbors

					// update the values of v in the queue
					// Remove v from the Queue so that we can reinsert it
					// in a new place according to its new value to keep
					// the Linked List ordered
					Object residue = Queue.remove(indexNeighbor);

					// Get the new position for v
					int position = Collections.binarySearch(Queue, v,
							new Comparator() {
								public int compare(Object o1, Object o2) {
									Vertex v1 = (Vertex) o1;
									Vertex v2 = (Vertex) o2;

									if (v1.key < v2.key)
										return -1;
									if (v1.key == v2.key)
										return 0;
									return 1;
								}
							});

					// Adds v in its new position in Queue
					if (position < 0) // means it is not there
					{
						Queue.add(-(position + 1), v);
					} else // means it is there
					{
						Queue.add(position, v);
					}

				} // if 8-9.
			} // for all neighbors
		} // of while

		// Creates the new Graph that contains the SSSP
		String theName;
		Graph newGraph = new Graph();

		// Creates and adds the vertices with the same name
		for (i = 0; i < numvertices; i++) {
			theName = ((Vertex) vertices.get(i)).name;
			newGraph.addVertex(new Vertex().assignName(theName));
		}

		// Creates the edges from the NewGraph
		Vertex theVertex, thePred;
		Vertex theNewVertex, theNewPred;
		Edge e;

		// For each vertex in vertices list we find its predecessor
		// make an edge for the new graph from predecessor->vertex
		for (i = 0; i < numvertices; i++) {
			// theVertex and its Predecessor
			theVertex = (Vertex) vertices.get(i);
			thePred = findsVertex(theVertex.pred);

			// if theVertex is the source then continue we dont need
			// to create a new edge at all
			if (thePred == null)
				continue;

			// Find the references in the new Graph
			theNewVertex = newGraph.findsVertex(theVertex.name);
			theNewPred = newGraph.findsVertex(thePred.name);

			// Creates the new edge from predecessor -> vertex in the newGraph
			// and ajusts the adorns based on the old edge
			Edge theNewEdge = new Edge(theNewPred, theNewVertex);
			e = findsEdge(thePred, theVertex);
			theNewEdge.adjustAdorns(e);

			// Adds the new edge to the newGraph
			newGraph.addEdge(theNewEdge);
		}
		return newGraph;

	} // MST

	public void NumberVertices() {
		GraphSearch(new NumberWorkSpace());
	}

	public Reader inFile; // File handler for reading

	public static int ch; // Character to read/write

	// timmings
	static long last = 0, current = 0, accum = 0;

	public void runBenchmark(String FileName) throws IOException {
		try {
			inFile = new FileReader(FileName);
		} catch (IOException e) {
			System.out.println("Your file " + FileName + " cannot be read");
		}
	}

	public void stopBenchmark() throws IOException {
		inFile.close();
	}

	public int readNumber() throws IOException {
		int index = 0;
		char[] word = new char[80];
		int ch = 0;

		ch = inFile.read();
		while (ch == 32)
			ch = inFile.read(); // skips extra whitespaces

		while (ch != -1 && ch != 32 && ch != 10) // while it is not EOF, WS,
		// NL
		{
			word[index++] = (char) ch;
			ch = inFile.read();
		}
		word[index] = 0;

		String theString = new String(word);

		theString = new String(theString.substring(0, index));
		return Integer.parseInt(theString, 10);
	}

	public static void startProfile() {
		accum = 0;
		current = System.currentTimeMillis();
		last = current;
	}

	public static void stopProfile() {
		current = System.currentTimeMillis();
		accum = accum + (current - last);
	}

	public static void resumeProfile() {
		current = System.currentTimeMillis();
		last = current;
	}

	public static void endProfile() {
		current = System.currentTimeMillis();
		accum = accum + (current - last);
		System.out.println("Time elapsed: " + accum + " milliseconds");
	}

	public Graph ShortestPath(Vertex s) {
		Vertex source;

		source = s;
		int numvertices = vertices.size();
		int i;
		Vertex x, n;
		Neighbor vn;
		int wuvn;
		int k1;

		// 1. Initializes the single source
		for (i = 0; i < numvertices; i++) {
			x = (Vertex) vertices.get(i);
			x.predecessor = null;
			x.dweight = Integer.MAX_VALUE;
		}

		source.dweight = 0;
		source.predecessor = null;

		// 2. S <- empty set
		LinkedList S = new LinkedList();

		// 3. Queue <- V[G], copy the vertex in the graph in the priority queue
		LinkedList Queue = new LinkedList();
		for (i = 0; i < numvertices; i++) {
			x = (Vertex) vertices.get(i);
			if (x.dweight != 0) // this means, if this is not the source
				Queue.add(x);
		}

		// Inserts the source at the head of the queue
		Queue.addFirst(source);

		// 4. while Q!=0
		Vertex ucurrent;
		int j, k, l;
		int pos;
		LinkedList Uneighbors;
		Vertex u, v;
		Edge en;
		int wuv;

		while (Queue.size() != 0) {
			// 5. u <- Extract-Min(Q);
			u = (Vertex) Queue.removeFirst();

			// 6. S <- S U {u}
			S.add(u);

			// 7. for each vertex v adjacent to u
			Uneighbors = u.neighbors;

			// For all the neighbors
			for (k = 0; k < Uneighbors.size(); k++) {
				vn = (Neighbor) Uneighbors.get(k);
				v = vn.end;
				en = vn.edge;
				wuv = en.weight;

				// 8. Relax (u,v w)
				if (v.dweight > (u.dweight + wuv)) {
					v.dweight = u.dweight + wuv;
					v.predecessor = u.name;
					Uneighbors.set(k, vn); // adjust values in the neighbors

					// update the values of v in the queue
					int indexNeighbor = Queue.indexOf(v);
					if (indexNeighbor >= 0) {
						Object residue = Queue.remove(indexNeighbor);

						// Get the new position for v
						int position = Collections.binarySearch(Queue, v,
								new Comparator() {
									public int compare(Object o1, Object o2) {
										Vertex v1 = (Vertex) o1;
										Vertex v2 = (Vertex) o2;

										if (v1.dweight < v2.dweight)
											return -1;

										if (v1.dweight == v2.dweight)
											return 0;
										return 1;
									}
								});

						// Adds v in its new position in Queue
						if (position < 0) // means it is not there
						{
							Queue.add(-(position + 1), v);
						} else // means it is there
						{
							Queue.add(position, v);
						}

					} // if it is in the Queue

				} // if 8.
			} // for
		} // of while

		// Creates the new Graph that contains the SSSP
		String theName;
		Graph newGraph = new Graph();

		// Creates and adds the vertices with the same name
		for (i = 0; i < numvertices; i++) {
			theName = ((Vertex) vertices.get(i)).name;
			newGraph.addVertex(new Vertex().assignName(theName));
		}

		// Creates the edges from the NewGraph
		Vertex theVertex, thePred;
		Vertex theNewVertex, theNewPred;
		Edge e;
		Neighbor theNeighbor, newNeighbor;
		boolean flag = false;

		// For each vertex in vertices list we find its predecessor
		// make an edge for the new graph from predecessor->vertex
		for (i = 0; i < numvertices; i++) {
			// theVertex and its Predecessor
			theVertex = (Vertex) vertices.get(i);
			thePred = findsVertex(theVertex.predecessor);

			// if theVertex is the source then continue we dont need
			// to create a new edge at all
			if (thePred == null)
				continue;

			// Find the references in the new Graph
			theNewVertex = newGraph.findsVertex(theVertex.name);
			theNewPred = newGraph.findsVertex(thePred.name);

			// theNeighbor corresponds to the neighbor formed with
			// theVertex -> thePred
			// find the corresponding neighbor of the Vertex, that is,
			// predecessor
			j = 0;
			flag = false;
			do {
				theNeighbor = (Neighbor) (thePred.neighbors).get(j);
				if (theNeighbor.end.name.equals(theVertex.name))
					flag = true;
				else
					j++;
			} while (flag == false && j < thePred.neighbors.size());

			// Creates the new edge from predecessor -> vertex in the newGraph
			// and ajusts the adorns based on the old edge
			Edge theNewEdge = new Edge(theNewPred, theNewVertex);
			e = theNeighbor.edge;
			theNewEdge.adjustAdorns(e);

			// Adds the new edge to the newGraph
			newGraph.addEdge(theNewEdge);
		}

		return newGraph;

	} // shortest path

	public Graph StrongComponents() {

		FinishTimeWorkSpace FTWS = new FinishTimeWorkSpace();

		// 1. Computes the finishing times for each vertex
		GraphSearch(FTWS);

		// 2. Order in decreasing & call DFS Transposal
		Collections.sort(vertices, new Comparator() {
			public int compare(Object o1, Object o2) {
				Vertex v1 = (Vertex) o1;
				Vertex v2 = (Vertex) o2;

				if (v1.finishTime > v2.finishTime)
					return -1;

				if (v1.finishTime == v2.finishTime)
					return 0;
				return 1;
			}
		});

		// 3. Compute the transpose of G
		// Done at layer transpose
		Graph gaux = ComputeTranspose((Graph) this);

		// 4. Traverse the transpose G
		WorkSpaceTranspose WST = new WorkSpaceTranspose();
		gaux.GraphSearch(WST);

		return gaux;

	} // of Strong Components
}
