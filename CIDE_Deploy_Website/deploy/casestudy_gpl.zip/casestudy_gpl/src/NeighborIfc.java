
// *************************************************************************
// I believe this interface is always empty?

public interface NeighborIfc {
}
