import java.util.LinkedList;


public class GlobalVarsWrapper {
	  public static LinkedList<Vertex> queue =  new LinkedList<Vertex>();
}
