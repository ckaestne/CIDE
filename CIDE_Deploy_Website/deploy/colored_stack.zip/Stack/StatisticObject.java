
public class StatisticObject {

}
