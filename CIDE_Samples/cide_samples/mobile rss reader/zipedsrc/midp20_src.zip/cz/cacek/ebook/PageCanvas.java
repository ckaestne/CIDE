/*
 * PageCanvas.java
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP20
// Expand to define test define
//#define DNOTEST

//#ifdef DMIDP20
/* This isn't used now, so only compile for testing. */
//#ifdef DTEST
//@package cz.cacek.ebook;
//@
//@import java.util.Vector;
//@
//@import javax.microedition.lcdui.Canvas;
//@import javax.microedition.lcdui.Choice;
//@import javax.microedition.lcdui.Command;
//@import javax.microedition.lcdui.CommandListener;
//@import javax.microedition.lcdui.Display;
//@import javax.microedition.lcdui.Displayable;
//@import javax.microedition.lcdui.Font;
//@import javax.microedition.lcdui.Form;
//@import javax.microedition.lcdui.Gauge;
//@import javax.microedition.lcdui.Graphics;
//@import javax.microedition.lcdui.StringItem;
//@
//@import cz.cacek.ebook.util.ResourceProviderME;
//@import com.substanceofcode.rssreader.presentation.UiUtil;
//@import com.substanceofcode.rssreader.presentation.RssReaderMIDlet;
//@
//@/**
//@ * Main display. On this canvas is displayed current part of book.
//@ * @author Tom� Darmovzal [tomas.darmovzal (at) seznam.cz]
//@ * @author Josef Cacek [josef.cacek (at) atlas.cz]
//@ * @author Jiri Bartos
//@ * @author $Author: kwart $
//@ * @version $Revision: 1.18 $
//@ * @created $Date: 2006/12/26 09:08:49 $
//@ */
//@public class PageCanvas extends Canvas implements CommandListener {
//@
//@	private RssReaderMIDlet midlet;
//@	protected View view;
//@	private String message = null;
//@	private Font messageFont;
//@	private Command cmdInfo;
//@	private Command cmdPosition;
//@
//@	private Command cmdOK;
//@	private Command cmdCancel;
//@	
//@	private Gauge gauge;
//@	private Form form;
//@	
//@	protected final ScrollThread scrollThread  = new ScrollThread();
//@
//@	private Vector listVector;
//@	private static int scrollDelay = Common.AUTOSCROLL_PAUSE;
//@
//@	private byte screenIdx;
//@	private Display display;
//@
//@	/**
//@	 * Thread which provides autoscroll functionality.
//@	 * @author Josef Cacek
//@	 */
//@	class ScrollThread extends Thread {
//@		boolean run = false;
//@
//@		public void run() {			
//@			try {				
//@				while (true) {
//@					if (canRun()) {
//@						if (!view.fwdLine()) {
//@							setRun(false);	
//@						}						
//@						messageOff();
//@					}
//@					Thread.sleep(getScrollDelay());
//@				}
//@			} catch (Exception e) {}
//@		}
//@
//@		public void setRun(final boolean aRun) {
//@			synchronized(this) {
//@				run = aRun;
//@				if (!run) {
//@					messageOff();
//@				}
//@			}
//@		}
//@
//@		public boolean canRun() {
//@			synchronized(this) {
//@				return run;
//@			}
//@		}
//@	}
//@
//@	/**
//@	 * Constructor
//@	 * @param aMidlet
//@	 * @throws Exception
//@	 */
//@	public PageCanvas(RssReaderMIDlet aMidlet) throws Exception {
//@		midlet = aMidlet;
//@		display = Display.getDisplay(midlet);
//@		view = new View(getWidth(), getHeight(), Font.SIZE_SMALL);
//@		messageFont = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD,
//@			Font.SIZE_SMALL);
//@		cmdInfo = UiUtil.getCmdRsc("page.cmd.info", Command.SCREEN, 3);
//@		cmdPosition = UiUtil.getCmdRsc("page.cmd.position", Command.SCREEN, 2);
//@		cmdOK = UiUtil.getCmdRsc("cmd.ok", Command.OK, 1);
//@		cmdCancel = UiUtil.getCmdRsc("cmd.cancel", Command.CANCEL, 1);
//@		addCommand(cmdPosition);
//@		addCommand(cmdInfo);
//@		scrollThread.start();
//@	}
//@
//@
//@	/**
//@	 * Constructs reusable gauge screen.
//@	 * @param aHead resource key for screen header
//@	 * @param aGauge resource key for gauge description
//@	 * @param aValue initial value on gauge
//@	 */
//@	private void createGaugeForm(final String aHead, final String aGauge, final int aValue, final byte aScreenIdx) {
//@		form = new Form(ResourceProviderME.get(aHead));
//@		if (aValue<0 || aValue>100) {
//@			throw new RuntimeException("Wrong parameters for Gauge constructor");
//@		}
//@		gauge = new Gauge(ResourceProviderME.get(aGauge), true, 100, 0);
//@		form.append(gauge);
//@        gauge.setValue(aValue);
//@		form.addCommand(cmdOK);
//@		form.addCommand(cmdCancel);
//@		form.setCommandListener(this);
//@		display.setCurrent(form);
//@		screenIdx = aScreenIdx;
//@	}
//@
//@	private void releaseForm() {
//@		form = null;
//@		gauge = null;
//@		setPageScreen();
//@	}
//@	
//@	/*
//@	 * (non-Javadoc)
//@	 * 
//@	 * @see javax.microedition.lcdui.Displayable#paint(javax.microedition.lcdui.Graphics)
//@	 */
//@	public void paint(Graphics g) {
		//#ifdef DTEST
//@		Common.debug("PageCanvas.paint(Graphics g)");
		//#endif
//@		view.draw(g, 0, 0);
//@		if (message != null) {
//@			int mx = 2;
//@			int my = 2;
//@			g.setFont(messageFont);
//@			int w = messageFont.stringWidth(message);
//@			int h = messageFont.getHeight();
//@			g.setColor(0xFFFFFF);
//@			g.fillRect(mx, my, w + 3, h + 3);
//@			g.setColor(0x000000);
//@			g.drawString(message, mx + 2, my + 2, Graphics.LEFT | Graphics.TOP);
//@			g.drawRect(mx, my, w + 3, h + 3);
//@		}
//@	}
//@
//@	/* (non-Javadoc)
//@	 * @see javax.microedition.lcdui.Displayable#keyPressed(int)
//@	 */
//@	public void keyPressed(int aKey) {
		//#ifdef DTEST
//@		Common.debug("Key pressed " + aKey);
		//#endif
//@		key(aKey);
//@	}
//@
//@	/* (non-Javadoc)
//@	 * @see javax.microedition.lcdui.Displayable#keyRepeated(int)
//@	 */
//@	public void keyRepeated(int aKey) {
		//#ifdef DTEST
//@		Common.debug("Key repeated " + aKey);
		//#endif
//@		key(aKey);
//@	}
//@
//@	/**
//@	 * Key actions handler
//@	 * @param aKey
//@	 */
//@	protected void key(final int aKey) {
//@		synchronized(this) {
//@			final int action = getGameAction(aKey);
			//#ifdef DTEST
//@			Common.debug("Key: " + aKey + ", Action: " + action);
			//#endif
//@			if (!scrollThread.canRun()) {
//@				keyNormal(aKey, action);
//@			} else {
//@				keyAutoRun(aKey, action);					
//@			}
			//#ifdef DTEST
//@			Common.debug("Key action finished.");
			//#endif
//@		}
//@	}
//@
//@
//@	/**
//@	 * Key actions handler
//@	 * @param aKey
//@	 */
//@	protected void keyNormal(final int aKey, final int action) {
//@		switch (action) {
//@			case UP:
//@				prevPage();
//@				break;
//@			case DOWN:
//@				nextPage();
//@				break;
//@			case RIGHT:
//@				nextLine();
//@				break;
//@			case LEFT:
//@				prevLine();
//@				break;
//@			default:
//@				switch (aKey) {
//@					case KEY_NUM1:
//@					case KEY_NUM2:
//@					case KEY_NUM3:
//@					case -13:
//@						prevPage();
//@						break;
//@					case KEY_NUM4:
//@						prevLine();
//@						break;
//@					case KEY_NUM7:
//@					case KEY_NUM8:
//@					case KEY_NUM9:
//@					case KEY_NUM0:
//@					case -14:
//@						nextPage();
//@						break;
//@					case KEY_NUM6:
//@						nextLine();
//@						break;
//@					case KEY_NUM5:
//@						scrollThread.setRun(true);
//@						break;
//@				}
//@		}
//@	}
//@
//@	/**
//@	 * Key handlers for Autorun book reading.
//@	 * @param aKey
//@	 */
//@	protected void keyAutoRun(final int aKey, final int action) {
//@		if (action == UP || action == LEFT || aKey == KEY_NUM4) {
//@			addScrollDelay(Common.AUTOSCROLL_STEP);
//@		} else if (action == DOWN || action == RIGHT || aKey == KEY_NUM6) {
//@			addScrollDelay(- Common.AUTOSCROLL_STEP);
//@		} 
//@		if (aKey == KEY_NUM5) {
//@			messageOn(ResourceProviderME.get("i.stop"));
//@			scrollThread.setRun(false);
//@		} else {
//@			messageOn(ResourceProviderME.get("i.delay")+getScrollDelay());
//@		}
//@	}
//@	/* (non-Javadoc)
//@	 * @see javax.microedition.lcdui.Displayable#pointerPressed(int, int)
//@	 */
//@	public void pointerPressed(int aX, int aY) {
		//#ifdef DTEST
//@		Common.debug("Pointer pressed (" + aX + "," + aY + ")");
		//#endif
//@		int seg = (aY * 4) / getHeight();
//@		if (scrollThread != null) {
//@			return;
//@		}
//@		synchronized (this) {
//@			switch (seg) {
//@				case 0:
//@					prevPage();
//@					break;
//@				case 1:
//@					prevLine();
//@					break;
//@				case 2:
//@					nextLine();
//@					break;
//@				case 3:
//@					nextPage();
//@					break;
//@			}
//@		}
//@	}
//@
//@	/* (non-Javadoc)
//@	 * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
//@	 */
//@	public void commandAction(Command aCmd, Displayable aDisp) {
		//#ifdef DTEST
//@		Common.debug("Command action " + aCmd);
		//#endif
//@		switch (screenIdx) {
//@			case Common.SCREEN_PAGE :
//@				commandActNormal(aCmd);
//@				break;
//@			case Common.SCREEN_POSITION :
//@				commandActPosition(aCmd);
//@				break;
//@			default :
//@				break;
//@		}
//@
//@	}
//@
//@  /**
//@   * 
//@   * @param Command
//@   * @author Irv Bunton
//@   */
//@	private void commandActPosition(final Command aCmd) {
		//#ifdef DTEST
//@		Common.debug("commandAction() for page started");
		//#endif
//@		if (form != null) {
//@			if (aCmd == cmdOK) {
//@				view.setPercPosition(gauge.getValue());
//@				view.fillPage();
//@			}
//@			releaseForm();
//@		}
//@	}
//@
//@	/**
//@	 * Set the page to show
//@	 */
//@	public void setPage(final Page page) {
//@		view.setPage(page);
//@		setPageScreen();
//@	}
//@
//@	private void setPageScreen() {
//@		display.setCurrent(this);
//@		screenIdx = Common.SCREEN_PAGE;
//@	}
//@	
//@	private void commandActNormal(final Command aCmd) {
//@		if (aCmd == cmdPosition) {
//@			createGaugeForm("page.pos.head", "page.pos.actual", view.getPercPosition(), Common.SCREEN_POSITION);
//@		} else if (aCmd == cmdInfo) {
//@			midlet.showItemForm();
//@		}
//@	}
//@
//@	/**
//@	 * Scrolls one line ahead in current book
//@	 */
//@	protected void nextLine() {
//@		try {
//@			pauseOn();
//@			view.fwdLine();
//@			messageOff();
//@		} catch (Exception e) {
//@			e.printStackTrace();
//@		}
//@	}
//@
//@	/**
//@	 * Scrolls one page ahead in current book
//@	 */
//@	protected void nextPage() {
//@		try {
//@			pauseOn();
//@			view.fwdPage();
//@			messageOff();
//@		} catch (Exception e) {
//@			e.printStackTrace();
//@		}
//@	}
//@
//@	/**
//@	 * Scrolls one line back in current book
//@	 */
//@	protected void prevLine() {
//@		try {
//@			pauseOn();
//@			view.bckLine();
//@			messageOff();
//@		} catch (Exception e) {
//@			e.printStackTrace();
//@		}
//@	}
//@
//@	/**
//@	 * Scrolls one page back in current book
//@	 */
//@	protected void prevPage() {
//@		try {
//@			pauseOn();
//@			view.bckPage();
//@			messageOff();
//@		} catch (Exception e) {
//@			e.printStackTrace();
//@		}
//@	}
//@
//@	/**
//@	 * Displays "Wait" message
//@	 */
//@	protected void pauseOn() {
//@		messageOn(ResourceProviderME.get("i.wait"));
//@	}
//@
//@	/**
//@	 * Displays system message (e.g. Wait) display
//@	 */
//@	protected void messageOn(final String aMsg) {
//@		synchronized(this) {
//@			message = aMsg;
//@			repaint();
//@			serviceRepaints();
//@		}
//@	}
//@
//@	/**
//@	 * Disable system message (e.g. Wait) display
//@	 */
//@	protected void messageOff() {
//@		synchronized(this) {
//@			message = null;
//@			repaint();
//@			//		serviceRepaints();
//@		}
//@	}
//@
//@	/* (non-Javadoc)
//@	 * @see javax.microedition.lcdui.Displayable#hideNotify()
//@	 */
//@	protected void hideNotify() {
		//#ifdef DTEST
//@		Common.debug("PageCanvas.hideNotify()");
		//#endif
//@		scrollThread.setRun(false);
//@	}
//@
//@	/**
//@	 * Sets pause between scrolling.
//@	 * @param aDelay
//@	 */
//@	public synchronized static void setScrollDelay(int aDelay) {
//@		if (aDelay < Common.AUTOSCROLL_STEP) {
//@			aDelay = Common.AUTOSCROLL_STEP;
//@		}
//@		scrollDelay = aDelay;
//@	}
//@
//@	public synchronized static void addScrollDelay(int aDelay) {
//@		setScrollDelay(getScrollDelay() + aDelay);
//@	}
//@
//@	/**
//@	 * Returns position of view.
//@	 * @see View#getPosition()
//@	 * @return position of view
//@	 */
//@	public int getViewPosition() {
//@		return view.getPosition();
//@	}
//@
//@	/**
//@	 * @return Returns the scrollDelay.
//@	 */
//@	public synchronized static int getScrollDelay() {
//@		return scrollDelay;
//@	}
//@
//@}
//#endif
//#endif
