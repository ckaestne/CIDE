/*
 * SettingsForm.java
 *
 * Copyright (C) 2005-2006 Tommi Laukkanen
 * http://www.substanceofcode.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP20
// Expand to define DJSR75 define
//#define DJSR75
// Expand to define itunes define
//#define DITUNES
// Expand to define logging define
//#define DLOGGING
// Expand to define test ui define
//#define DTESTUI

package com.substanceofcode.rssreader.presentation;

import java.lang.IllegalArgumentException;
import java.io.IOException;
import java.util.Hashtable;

import com.substanceofcode.rssreader.businessentities.RssReaderSettings;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
//#ifndef DTESTUI
//@import javax.microedition.lcdui.ChoiceGroup;
//@import javax.microedition.lcdui.Form;
//@import javax.microedition.lcdui.TextField;
//@import javax.microedition.lcdui.StringItem;
//#else
// If using the test UI define the Test UI's
import com.substanceofcode.testlcdui.ChoiceGroup;
import com.substanceofcode.testlcdui.Form;
import com.substanceofcode.testlcdui.List;
import com.substanceofcode.testlcdui.TextBox;
import com.substanceofcode.testlcdui.TextField;
import com.substanceofcode.testlcdui.StringItem;
//#endif
import javax.microedition.lcdui.Item;

//#ifndef DSMALLMEM
import com.substanceofcode.rssreader.presentation.HelpForm;
//#endif

//#ifdef DJSR75
import org.kablog.kgui.KFileSelectorMgr;
//#endif
import com.substanceofcode.utils.Settings;
import cz.cacek.ebook.util.ResourceProviderME;

//#ifdef DLOGGING
import net.sf.jlogmicro.util.logging.Logger;
import net.sf.jlogmicro.util.logging.LogManager;
import net.sf.jlogmicro.util.logging.Level;
//#endif

/**
 *
 * @author Tommi Laukkanen
 */
public class SettingsForm extends Form implements CommandListener, Runnable {
    
    private RssReaderMIDlet m_midlet;
    private boolean m_getHelp = false;
    private boolean m_upd = false;
    private Command m_okCommand;
    private Command m_cancelCommand;
	//#ifndef DSMALLMEM
    private Command m_helpCommand;
	//#endif
    
    private TextField m_itemCountField;
    private ChoiceGroup m_markUnreadItems;
	//#ifndef DSMALLMEM
    private ChoiceGroup m_useTextBox;
	//#endif
    private ChoiceGroup m_useStandardExit;
    private ChoiceGroup m_feedListOpen;
	//#ifdef DITUNES
    private ChoiceGroup m_itunesEnabled;
	//#endif
	//#ifdef DMIDP20
    private ChoiceGroup m_pageEnabled;
    private ChoiceGroup m_fontSize;
	//#endif
    private TextField m_wordCountField;
    private StringItem m_pgmMemUsedItem;
    private StringItem m_pgmMemAvailItem;
    private StringItem m_memUsedItem;
    private StringItem m_memAvailItem;
    private StringItem m_threadsUsed;
    private boolean prevStdExit;
	//#ifdef DLOGGING
    private TextField m_logLevelField;
    private Logger logger = Logger.getLogger("SettingsForm");
    private boolean fineLoggable = logger.isLoggable(Level.FINE);
    private boolean finerLoggable = logger.isLoggable(Level.FINER);
    private boolean finestLoggable = logger.isLoggable(Level.FINEST);
	//#endif
    
    /** Creates a new instance of SettingsForm */
    public SettingsForm(RssReaderMIDlet midlet) {
        super("Settings");
        m_midlet = midlet;
        
        m_okCommand = UiUtil.getCmdRsc("cmd.ok", Command.OK, 1);
        this.addCommand( m_okCommand );
        
        m_cancelCommand = UiUtil.getCmdRsc("cmd.cancel", Command.CANCEL, 2);
        this.addCommand( m_cancelCommand );
        
		//#ifndef DSMALLMEM
        m_helpCommand = UiUtil.getCmdRsc("cmd.help", Command.HELP, 3);
        this.addCommand( m_helpCommand );
		//#endif

        this.setCommandListener( this );
        
        RssReaderSettings settings = m_midlet.getSettings();
        int maxCount = settings.getMaximumItemCountInFeed();
        
        m_itemCountField = new TextField("Max item count in feed",
                String.valueOf(maxCount), 3, TextField.NUMERIC);
		//#ifdef DMIDP20
		m_itemCountField.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_itemCountField );
		String [] choices = {"Mark", "No mark"};
        m_markUnreadItems = new ChoiceGroup("Mark unread items",
				                            Choice.EXCLUSIVE, choices, null);
		//#ifdef DMIDP20
		m_markUnreadItems.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_markUnreadItems );
		//#ifndef DSMALLMEM
		String [] txtChoices = {"Text (large) box", "Text (line) field"};
        m_useTextBox = new ChoiceGroup("Text entry items",
				                            Choice.EXCLUSIVE, txtChoices, null);
		//#ifdef DMIDP20
		m_useTextBox.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_useTextBox );
		//#endif
		String [] txtExit = {"Use standard exit key", "Use menu exit key"};
        m_useStandardExit = new ChoiceGroup("Exit key type",
				                            Choice.EXCLUSIVE, txtExit, null);
		//#ifdef DMIDP20
		m_useStandardExit.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        this.append( m_useStandardExit );
		//#ifdef DITUNES
		String [] itunesEnabledChoices = {"Don't show Itunes data",
				"Show Itunes data"};
        m_itunesEnabled = new ChoiceGroup("Choose to use Itunes data",
				                            Choice.EXCLUSIVE,
											itunesEnabledChoices,
											null);
		//#ifdef DMIDP20
		m_itunesEnabled.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_itunesEnabled );
		//#endif
		//#ifdef DMIDP20
		String [] pageEnabledChoices = {
			"Use commands to go back to previous screen",
				"Also use keypad to go back to previous screen"};
        m_pageEnabled = new ChoiceGroup("Choose to use keypad for item screen",
				                            Choice.EXCLUSIVE,
											pageEnabledChoices,
											null);
		m_pageEnabled.setLayout(Item.LAYOUT_BOTTOM);
        super.append( m_pageEnabled );
		String [] fontSizeChoices = {"Default font size", "Small", "Medium", "Large"};
        m_fontSize = new ChoiceGroup("Choose font size", Choice.EXCLUSIVE,
				fontSizeChoices,
											null);
		m_fontSize.setLayout(Item.LAYOUT_BOTTOM);
        super.append( m_fontSize );
		//#endif
		String [] feedBackChoices = {"Open item first", "Back first"};
        m_feedListOpen = new ChoiceGroup("Choose feed list menu first item",
				                            Choice.EXCLUSIVE, feedBackChoices,
											null);
		//#ifdef DMIDP20
		m_feedListOpen.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_feedListOpen );
        int maxWordCount = settings.getMaxWordCountInDesc();
        m_wordCountField = new TextField("Max word count desc abbrev",
                String.valueOf(maxCount), 3, TextField.NUMERIC);
		//#ifdef DMIDP20
		m_wordCountField.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_wordCountField );
		StringItem itemInfo = new StringItem("Program MIDP version:",
		//#ifdef DMIDP20
				"MIDP-2.0");
		//#else
//@				"MIDP-1.0");
		//#endif
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( itemInfo );
        itemInfo = new StringItem("Program CLDC version:",
				//#ifdef DCLDCV11
//@				"CLDC-1.1");
				//#else
				"CLDC-1.0");
				//#endif
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( itemInfo );
        itemInfo = new StringItem("Program JSR 75 available:",
		//#ifdef DJSR75
				"true");
		//#else
//@				"false");
		//#endif
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( itemInfo );
		String mep = System.getProperty("microedition.profiles");
		if (mep == null) {
			mep = "N/A";
		}
        itemInfo = new StringItem("Phone MIDP version:", mep);
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( itemInfo );
        itemInfo = new StringItem("Phone CLDC version:",
				System.getProperty("microedition.configuration"));
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( itemInfo );
        itemInfo = new StringItem("Phone JSR 75 available:",
				new Boolean(System.getProperty(
				"microedition.io.file.FileConnection.version")
				!= null).toString());
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( itemInfo );
		String me = System.getProperty("microedition.platform");
		if (me == null) {
			me = "N/A";
		}
        itemInfo = new StringItem("Phone Microedition platform:", me);
		//#ifdef DMIDP20
		itemInfo.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        this.append( itemInfo );
		//#ifdef DLOGGING
        m_logLevelField = new TextField("Logging level",
                logger.getParent().getLevel().getName(), 20, TextField.ANY);
		//#ifdef DMIDP20
		m_logLevelField.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_logLevelField );
		//#endif
        m_pgmMemUsedItem = new StringItem("Application memory used:", "");
		//#ifdef DMIDP20
		m_pgmMemUsedItem.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_pgmMemUsedItem );
        m_pgmMemAvailItem = new StringItem("Application memory available:", "");
		//#ifdef DMIDP20
		m_pgmMemAvailItem.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_pgmMemAvailItem );
        m_memUsedItem = new StringItem("DB memory used:", "");
		//#ifdef DMIDP20
		m_memUsedItem.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_memUsedItem );
        m_memAvailItem = new StringItem("DB memory available:", "");
		//#ifdef DMIDP20
		m_memAvailItem.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_memAvailItem );
        m_threadsUsed = new StringItem("Active Threads:", "");
		//#ifdef DMIDP20
		m_threadsUsed.setLayout(Item.LAYOUT_BOTTOM);
		//#endif
        super.append( m_threadsUsed );
		updateForm();
    }
    
	/* Update form items that change per run. */
	public void updateForm() {
        RssReaderSettings settings = m_midlet.getSettings();
        int maxCount = settings.getMaximumItemCountInFeed();
        m_itemCountField.setString(String.valueOf(maxCount));
        boolean markUnreadItems = settings.getMarkUnreadItems();
		boolean [] selectedItems = {markUnreadItems, !markUnreadItems};
		m_markUnreadItems.setSelectedFlags( selectedItems );
		//#ifndef DSMALLMEM
        boolean useTextBox = settings.getUseTextBox();
		boolean [] boolSelectedItems = {useTextBox, !useTextBox};
		m_useTextBox.setSelectedFlags( boolSelectedItems );
		//#endif
        boolean useStdExit = settings.getUseStandardExit();
        prevStdExit = useStdExit;
		boolean [] boolExitItems = {useStdExit, !useStdExit};
		m_useStandardExit.setSelectedFlags( boolExitItems );
		//#ifdef DITUNES
        boolean itunesEnabled = settings.getItunesEnabled();
		boolean [] boolItunesEnabled = {!itunesEnabled, itunesEnabled};
		m_itunesEnabled.setSelectedFlags( boolItunesEnabled );
		//#endif
		//#ifdef DMIDP20
        boolean pageEnabled = settings.getPageEnabled();
		boolean [] boolPageEnabled = {!pageEnabled, pageEnabled};
		m_pageEnabled.setSelectedFlags( boolPageEnabled );
        int fontSize = settings.getFontSize();
		boolean [] boolfontSize = {false, false, false, false};
		m_fontSize.setSelectedFlags( boolfontSize );
		m_fontSize.setSelectedIndex( fontSize, true );
		//#endif
        boolean feedListOpen = settings.getFeedListOpen();
		boolean [] boolFeedListOpen = {feedListOpen, !feedListOpen};
		m_feedListOpen.setSelectedFlags( boolFeedListOpen );

		long totalMem;
		long freeMem;
		System.gc();
		totalMem = Runtime.getRuntime().totalMemory();
		freeMem = Runtime.getRuntime().freeMemory();
		m_pgmMemUsedItem.setText(((totalMem - freeMem)/1024L) + "kb");
		m_pgmMemAvailItem.setText((freeMem/1024L) + "kb");
		Hashtable memInfo;
		try {
			memInfo = settings.getSettingMemInfo();
		} catch (Throwable e) {
			m_midlet.recordExcFormFinRsc("exc.int.err", e);
			memInfo = new Hashtable();
		}
        if (memInfo.size() == 0) {
			m_memUsedItem.setText("0");
			m_memAvailItem.setText("0");
		} else {
			m_memUsedItem.setText((String)memInfo.get("used"));
			m_memAvailItem.setText((String)memInfo.get("available"));
		}
		m_threadsUsed.setText(Integer.toString(Thread.activeCount()));
	}

    public void commandAction(Command command, Displayable displayable) {
		//#ifdef DTESTUI
		super.outputCmdAct(command, displayable);
		//#endif
        if(command==m_okCommand) {
			/* Loading data... */
			m_midlet.showLoadingFormRsc("text.u.data", this);
			m_upd = true;
			try {
				new Thread(this).start();
            } catch(Throwable e) {
				/* Internal error.:\n */
				m_midlet.recordExcFormFinRsc("exc.int.err", e);
            }
        }
        
        if(command==m_cancelCommand) {
            m_midlet.showBookmarkList();
        }

		//#ifndef DSMALLMEM
        if(command==m_helpCommand) {
			/* Loading help... */
			m_midlet.showLoadingFormRsc("text.l.h", this);
			m_getHelp = true;
			try {
				new Thread(this).start();
            } catch(Throwable e) {
				/* Internal error.:\n */
				m_midlet.recordExcFormFinRsc("exc.int.err", e);
            }
		}
		//#endif

    }
    
	public void run() {
        if(m_upd) {
			m_upd = false;
            // Save settings
            try {
				RssReaderSettings settings = m_midlet.getSettings();
                int maxCount = Integer.parseInt( m_itemCountField.getString() );
                settings.setMaximumItemCountInFeed( maxCount );
				boolean markUnreadItems = m_markUnreadItems.isSelected(0);
                settings.setMarkUnreadItems( markUnreadItems );
				//#ifndef DSMALLMEM
				boolean useTextBox = m_useTextBox.isSelected(0);
				settings.setUseTextBox(useTextBox);
				//#endif
				boolean useStdExit = m_useStandardExit.isSelected(0);
				settings.setUseStandardExit(useStdExit);
				if (useStdExit != prevStdExit) {
					m_midlet.initExit();
				}
				//#ifdef DITUNES
				boolean itunesEnabled = !m_itunesEnabled.isSelected(0);
				settings.setItunesEnabled( itunesEnabled );
				//#else
//@				settings.setItunesEnabled( false );
				//#endif
				//#ifdef DMIDP20
				boolean pageEnabled = !m_pageEnabled.isSelected(0);
				settings.setPageEnabled( pageEnabled );
				int fontSize = m_fontSize.getSelectedIndex();
				settings.setFontSize( fontSize );
				//#endif
				boolean feedListOpen = m_feedListOpen.isSelected(0);
				settings.setFeedListOpen( feedListOpen);
                int maxWordCount = Integer.parseInt( m_wordCountField.getString() );
                settings.setMaxWordCountInDesc( maxWordCount );
				//#ifdef DLOGGING
				try {
					String logLevel =
						m_logLevelField.getString().toUpperCase();
					logger.getParent().setLevel(Level.parse(logLevel));
					settings.setLogLevel( logLevel );
				} catch (IllegalArgumentException e) {
					Alert invalidData = new Alert("Invalid Log Level",
									"Invalid Log Level " +
									m_logLevelField.getString(),
									null,
									AlertType.ERROR);
					invalidData.setTimeout(Alert.FOREVER);
					Display.getDisplay(m_midlet).setCurrent(invalidData, this);
					return;
				}
				//#endif
				m_midlet.showBookmarkList();
            } catch(Exception e) {
				/* Internal error.:\n */
				m_midlet.recordExcFormFinRsc("exc.int.err", e);
            } catch(Throwable e) {
				/* Internal error.:\n */
				m_midlet.recordExcFormFinRsc("exc.int.err", e);
            }
            
		}

		//#ifndef DSMALLMEM
        if(m_getHelp) {
			m_getHelp = false;
			try {
				final HelpForm helpForm = new HelpForm(m_midlet, this);
				helpForm.appendRsc("text.set.help");
				helpForm.appendItemHelpRsc(m_useTextBox, "text.stxt.help");
				//#ifdef DMIDP20
				helpForm.appendItemHelpRsc(m_pageEnabled, "text.spg.help");
				helpForm.appendItemHelpRsc(m_fontSize, "text.sfs.help");
				//#endif
				m_midlet.setCurrent(helpForm);
            } catch(Throwable e) {
				/* Internal error.:\n */
				m_midlet.recordExcFormFinRsc("exc.int.err", e);
            }
        }
		//#endif

	}
}
