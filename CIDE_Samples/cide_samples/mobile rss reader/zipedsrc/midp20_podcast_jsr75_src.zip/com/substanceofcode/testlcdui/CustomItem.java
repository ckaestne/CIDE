/*
 * CustomItem.java
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP20
// Expand to define test define
//#define DTEST
// Expand to define test ui define
//#define DTESTUI
// Expand to define logging define
//#define DLOGGING

//#ifdef DTESTUI
//#ifdef DMIDP20
package cz.cacek.ebook;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.ItemCommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;

import com.substanceofcode.testutil.TestOutput;

/**
 * @author Irving Bunton, Jr
 * @version $Revision: 1.18 $
 * @created $Date: 2006/12/26 09:08:49 $
 */
abstract public class CustomItem extends javax.microedition.lcdui.CustomItem
implements ItemCommandListener {

	private ItemCommandListener m_itemCmdListener;

	/**
	 * Constructor
	 * Set the page to show
	 * @param aLabel - albel name
	 * @param aFrmWidth - form width
	 * @param aMidlet - midlet
	 * @throws Exception
	 */
	public CustomItem(String label) {
		super(label);
		TestOutput.println("Test UI Custom Item Label: " + label);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.microedition.lcdui.Displayable#paint(javax.microedition.lcdui.Graphics)
	 */
	public void logPaint(Graphics g, int width, int height) {
		TestOutput.println("Test UI Custom Item width, height: " + width + "," + height);
	}

	/**
	 * @return Returns width of last paint.
	 */
	public int getMinimumWidth() {
		int rtn = super.getMinimumWidth();
		TestOutput.println("Test UI Custom Item getMinimumWidth: [" + getLabel() + "]," +rtn);
		return rtn;
	}

	/**
	 * @return Returns height of last paint.
	 */
	public int getMinimumHeight() {
		int rtn = super.getMinimumHeight();
		TestOutput.println("Test UI Custom Item getMinimumHeight: [" + getLabel() + "]," +rtn);
		return rtn;
	}

	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Item)
	 */
	public void commandAction(Command cmd, Item item) {
		TestOutput.println("Test UI StringItem command,item=" + cmd.getLabel() + "," + item.getLabel());
		m_itemCmdListener.commandAction(cmd, item);
	}

    public void setItemCommandListener(ItemCommandListener itemCmdListener) {
        this.m_itemCmdListener = itemCmdListener;
		super.setItemCommandListener(this);
    }
}
//#endif
//#endif
