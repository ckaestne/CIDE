package de.ovgu.cide.jakutil;

public @interface MethodObject {
}
