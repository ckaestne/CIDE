package coloredide.editor;

public class ColorHider {

}
