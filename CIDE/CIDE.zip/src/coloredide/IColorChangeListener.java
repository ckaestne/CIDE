package coloredide;



public interface IColorChangeListener {
	void colorChanged(ColorChangedEvent event);
}
