package coloredide.configuration;


public abstract class CodePrinter {

	
}
