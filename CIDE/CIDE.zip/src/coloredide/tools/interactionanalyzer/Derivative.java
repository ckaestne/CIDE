package coloredide.tools.interactionanalyzer;

public interface Derivative extends Comparable {

	public abstract String getDerivativeStr();

}