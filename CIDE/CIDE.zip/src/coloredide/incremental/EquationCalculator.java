package coloredide.incremental;

import java.util.List;

import coloredide.features.Feature;

public class EquationCalculator implements Visitor
{
	public static EquationCalculator INSTANCE = new EquationCalculator();
	protected Equation equation;
	
	/**
	 * Fills the deltas in the specified equation from the specified root 
	 * by traversing the root.
	 * In equation, the last feature should be the last element.
	 * @param equation
	 * @param root
	 */
	public void fillEquation(Equation equation, Delta root)
	{
		this.equation = equation;
		root.acceptBFT(this);
	}

	public boolean visit(Delta d)
	{
		List<Delta> path = d.getPath();
		// For each Delta, go through the equation from left to right and
		// add to the feature if the delta's path contains the feature
		for(int i = equation.getIncrementalFeatures().size()-1; i >= 0; i--)
		{			
			IncrementalFeature incFeature = equation.getIncrementalFeatures().get(i);
			if(pathContainsFeature(path, 
					incFeature.getFeature()))					
			{
				equation.addDeltaToFeature(d, incFeature);
				break;
			}
		}
		return true;
	}	
	
	private boolean pathContainsFeature(List<Delta> path, Feature feature)
	{
		boolean containsFeature = false;
		
		for(Delta d: path)
		{
			if((d.getFeature() != null && 
					(d.getFeature().compareTo(feature) == 0)) ||
				d.getFeature() == null && feature == null)
			{
				containsFeature = true;
				break;
			}
		}
		
		return containsFeature;
	}
}
