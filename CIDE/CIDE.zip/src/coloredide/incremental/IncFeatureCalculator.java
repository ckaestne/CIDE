package coloredide.incremental;

import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.ASTNode;

import coloredide.features.ASTColorInheritance;
import coloredide.features.Feature;
import coloredide.features.source.IColorManager;
import coloredide.utils.GenericVisitor;

public class IncFeatureCalculator extends GenericVisitor
{
	public static IncFeatureCalculator INSTANCE = new IncFeatureCalculator();	 
	private IColorManager cm;	
	private Delta root;
	
	public Delta getDeltaTree(IColorManager cm)
	{
		this.cm = cm;				
		root = new Delta();		
		try {
			cm.getSource().getAST().accept(this);
		} catch (JavaModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return root;
	}	
	
	protected boolean visitNode(ASTNode node)
	{
		Delta d = null;
		
		Set<Feature> ownColors = cm.getOwnColors(node);
		if(!ownColors.isEmpty())
		{			
			// TODO: take into account multiple own colors
			Feature ownColor = ownColors.iterator().next(); 
				
			// Find where this delta should be placed in the tree 
			// by computing the path of the parent delta
			// Assuming that the visit occurs DFS, so that parents exist first
			Delta parentDelta = getDelta(getInheritedFeaturePath(node));
			
			// See if this Delta already exists - could happen if there are multiple
			// sibling ASTs having the same nested color
			d = parentDelta.getChildren().get(ownColor);
			if(d == null)
			{
				d = new Delta();			
				d.setFeature(ownColor);
				d.setParent(parentDelta);
				parentDelta.getChildren().put(ownColor, d);						
			}
			d.getNodes().add(node);				
		}
		
		return true;
	}
	
	private Delta getDelta(List<Feature> featurePath)
	{
		Delta d = root;
		
		for(int i = featurePath.size()-1; i >= 0; i--)
		{
			Feature f = featurePath.get(i);
			d = d.getChildren().get(f);
		}
				
		return d;
	}
	
	// Like getInheritedColors, but with a List instead of a Set
	private List<Feature> getInheritedFeaturePath(ASTNode node)
	{
		List<Feature> result = new Vector<Feature>();		
			
		ASTNode parent = node.getParent();
		if (parent != null)
		{
			// Make sure that parent has only colour here
			if (ASTColorInheritance.inheritsColors(parent, node))					
				result.addAll(cm.getOwnColors(parent));
			result.addAll(getInheritedFeaturePath(parent));					
		}

		return result;
	}
}
