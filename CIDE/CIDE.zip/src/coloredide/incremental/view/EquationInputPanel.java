package coloredide.incremental.view;

import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

import coloredide.incremental.Delta;
import coloredide.incremental.Equation;
import coloredide.incremental.EquationCalculator;
import coloredide.incremental.IncrementalFeature;

public class EquationInputPanel extends Composite
{
	// Delimiter separating features in an equation
	public static final String FEATURE_DELIMITER = "*";
	
	// List of IncrementalFeatures from which different equations (orderings) 
	// can be constructed.
	protected List<IncrementalFeature> incFeatures;
	
	// Text field for entering the equation
	protected Text equationField;
	
	// Button for making the equation in the field effective
	protected Button okButton;
	
	// reference to project
	protected IProject project;

		
	/**
	 * Equation listener should call fillEquation(.) and display error message or the 
	 * filled equation.
	 * @param parent
	 * @param style
	 * @param equationChangeListener
	 */
	public EquationInputPanel(Composite parent, int style, Listener equationChangeListener)
	{
		super(parent, style);
		initLayout(equationChangeListener);
	}
	
	private void initLayout(Listener equationChangeListener)
	{
		setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		setLayout(gridLayout);
		
		equationField = new Text(this, SWT.SINGLE | SWT.BORDER);
		equationField.setTextLimit(30);
		GridData gridData = new GridData();
		gridData.widthHint = 300;
		gridData.heightHint = 10;		
		equationField.setLayoutData(gridData);
		
		okButton = new Button(this, SWT.PUSH);
		okButton.setText("OK");
		okButton.addListener(SWT.Selection, equationChangeListener);
		gridData = new GridData();
		gridData.widthHint = 70;
		gridData.heightHint = 20;
		okButton.setLayoutData(gridData);					
	}
		
	public void setIncrementalFeatures(List<IncrementalFeature> incFeatures, IProject project)
	{
		this.incFeatures = incFeatures;		
		this.project = project;
	}
	
	/**
	 * Fills the specified equation from the GUI.  Pass in a newly created Equation
	 * and this function will fill it with the ordering from the GUI and also will calculate the 
	 * deltas from the specified root delta.  Returns the error value, which is empty if 
	 * it was successful. 
	 * @param equation
	 * @return
	 */
	public String getEquation(Equation equation, Delta root)
	{
		String[] tokens = equationField.getText().split("\\" + FEATURE_DELIMITER);
		String errorMessages = "";
		
		// Check if there are correct number of features
		if(tokens.length == incFeatures.size())
		{		
			int i;
			for(i = 0; i < tokens.length; i++)
			{
				// Check if there are multiple tokens
				boolean containsMultiple = false;
				for(int k = i-1; k >= 0; k--)
				{
					if(tokens[i].trim().equals(tokens[k].trim()))
					{
						containsMultiple = true;
						errorMessages += "Feature '" + tokens[i].trim() + "' appears more than once.\n";
						break;
					}
				}
				if(containsMultiple)
					break;
	
				// Check if 0 is at the beginning
				if(i == (tokens.length-1) && !tokens[i].trim().equals(IncrementalFeature.BASE))
					break;
				
				// Check if the token is a valid feature
				IncrementalFeature incFeature = null;
				for(int j = 0; j < incFeatures.size(); j++)
				{		
					// If the feature names match or if it's the base constant
					if((incFeatures.get(j).getFeature() != null && tokens[i].trim().equals
						(incFeatures.get(j).getFeature().getShortName(project))) ||
					  (incFeatures.get(j).getFeature() == null && tokens[i].trim().equals(IncrementalFeature.BASE)))
					{
						incFeature = incFeatures.get(j);
						break;
					}										
				}
				if(incFeature == null)
				{
					errorMessages += "Token '" + tokens[i].trim() + "' is not a valid feature.\n";		
					break;
				}
				
				// Finally, the corresponding IncrementalFeature can be placed into the equation
				// First in is the last feature
				equation.getIncrementalFeatures().add(0, incFeature);
			}
			
			// On success, fill the equation with the deltas
			// There should be at least 2 features: Base + other features
			if(errorMessages.length() == 0)
			{
				if(equation.getIncrementalFeatures().size() >= 2)
					EquationCalculator.INSTANCE.fillEquation(equation, root);
				else
					errorMessages += "There are not enough features (" + equation.getIncrementalFeatures().size() + ") to show incremental development.\n";  
			}			
		}
		else
		{
			errorMessages += "The number of features entered (" + tokens.length + ") does not\n" +
					"match the number of actual features (" + incFeatures.size() + ").\n";			
		}
				
		return errorMessages;
	}
}
