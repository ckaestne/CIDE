package coloredide.incremental.view;

import java.util.List;
import java.util.Vector;

import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.ui.part.ViewPart;

import coloredide.editor.ColoredCompilationUnitEditor;
import coloredide.features.Feature;
import coloredide.features.FeatureManager;
import coloredide.features.source.ColoredJavaSourceFile;
import coloredide.features.source.IColoredJavaSourceFile;
import coloredide.incremental.Delta;
import coloredide.incremental.DependencyCalculator;
import coloredide.incremental.Equation;
import coloredide.incremental.IncFeatureCalculator;
import coloredide.incremental.IncrementalFeature;
import coloredide.incremental.Sudoku;

/**
 * UI for showing incremental development of a program
 * @author chpkim
 *
 */
public class IncrementalView extends ViewPart implements Listener
{
	// Something we always have to have - get rid of this dependency if possible
	protected IProject project;	
	
	// GUI elements
	protected EquationInputPanel equationInputPanel;
	protected EquationDisplay equationDisplay;
	
	// List of features that are present in the code base.
	// This is independent of a particular equation. 
	// This should be cleared when the code base changes or the 
	// colouring changes in any way.
	protected List<IncrementalFeature> incFeatures;	
	
	// Root delta calculated from the code base
	protected Delta root; 
	
	// Parent
	protected Composite parent; 
	
	@Override
	public void createPartControl(Composite parent)
	{		
		this.parent = parent;
		parent.setLayout(new GridLayout(1, true));
		parent.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		
		// Equation input panel
		equationInputPanel = new EquationInputPanel(parent, SWT.NONE, this);
		GridData gridData = new GridData();
		
		// Equation display
	    equationDisplay = new EquationDisplay(parent);
	  //  gridData = new GridData(GridData.FILL_HORIZONTAL);
	  //  equationDisplay.setLayoutData(gridData);
	    
	    parent.pack();
	}
			
	private void setIncrementalFeatures()
	{		
		try
		{
			// Get the editor and the project
			ColoredCompilationUnitEditor editorPart = 
				(ColoredCompilationUnitEditor)getSite().getPage().getActiveEditor();
			if(editorPart != null)
			{
				project = editorPart.getInputJavaElement().
									getCorrespondingResource().getProject();
				
				// TODO: Calculate the tree - this should be done for ALL the files, not just the active editor's file
		        IColoredJavaSourceFile sourceFile = ColoredJavaSourceFile.getColoredJavaSourceFile((ICompilationUnit) editorPart
						.getInputJavaElement());	
		        root = IncFeatureCalculator.INSTANCE.getDeltaTree(sourceFile.getColorManager());
		        
				// Get IncrementalFeatures from the features in the code base 
		        // - be careful of "getVisibleFeatures" because we are using (hacking)
		        // the visibility switch to show incremental development.
		        List<Feature> features = FeatureManager.getFeatures();
		        incFeatures = new Vector<IncrementalFeature>();
				IncrementalFeature emptyFeature = new IncrementalFeature();
				emptyFeature.setFeature(null);
				incFeatures.add(emptyFeature);							
				for(int i = features.size()-1; i >=0 ; i--)
				{
					// TODO: we have to have some way of identifying "active" features in the
					// system - not just "visible".  We're using name checking, but this is horrible
					if(!features.get(i).getShortName(project).startsWith("Feature"))
					{
						IncrementalFeature incFeature = new IncrementalFeature();
						incFeature.setFeature(features.get(i));
						incFeatures.add(incFeature);	
					}					
				}
				
				// Once we have the IncrementalFeatures, we should set up the dependencies between
				// them by running it through DependencyCalculator
				DependencyCalculator.INSTANCE.calculateDependencies(incFeatures, root);
				
				// Now that we have the complete IncrementalFeatures, set it in EquationInputPanel
				equationInputPanel.setIncrementalFeatures(incFeatures, project);
			}
		}
		catch (JavaModelException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}
	
	@Override
	public void setFocus()
	{
		// TODO Auto-generated method stub		
	}

	// When an equation is selected through EquationInputPanel, this method
	// will be invoked
	public void handleEvent(Event event)
	{
	//	Sudoku.start();
		
		// If the editor is not open, we cannot do anything
		if(getSite().getPage().getActiveEditor() != null)
		{
			// Set up incremental features if we haven't done so already or
			// if the code base has changed since then.
			if(incFeatures == null)
				setIncrementalFeatures();
			
			// Get the equation from the input panel
			Equation equation = new Equation();
			String errorMessages = equationInputPanel.getEquation(equation, root);
			if(errorMessages.length() == 0)
			{
				// Display the equation
				equationDisplay.setFeatureEquation(equation, project, getSite().getPage());
				//this.parent.pack(true);
				this.parent.redraw();
			}
			else
			{				
				 MessageBox messageBox =
					   new MessageBox(getSite().getShell(),
					    SWT.OK);
				 messageBox.setMessage(errorMessages);
				 messageBox.open();
			}
		}  		
	}	
}