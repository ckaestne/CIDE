package coloredide.incremental.view;

import org.eclipse.core.resources.IProject;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Slider;
import org.eclipse.ui.IWorkbenchPage;

import coloredide.features.FeatureNameManager;
import coloredide.incremental.Equation;

/**
 * This class is used to allow the user to input different 
 * feature equations.
 * @author chpkim
 *
 */
public class EquationDisplay extends Composite implements Listener
{
	// The equation currently in effect
	protected Equation equation;
	
	// A label for each IncrementalFeature in equation.  Selected features
	// will be colored with the background color, while non-selected features
	// will be colored with the defaultBackground color.
	protected Label[] labels;
	protected Color defaultBackground;
	protected static Color SELECTED_BACKGROUND = Display.getDefault().getSystemColor(SWT.COLOR_CYAN);
		
	// Required for refreshing
	protected IWorkbenchPage page;
	
	// We always need this to display the name of the features - TODO: get rid of 
	// this dependency
	protected IProject project;
	
	// Expression (features + their deltas) display
	protected Composite expressionDisplay;
	
	 // Slider
    protected Slider slider;
    
    // Parent
    protected Composite parent;
	
	public EquationDisplay(Composite parent)
	{
		super(parent, SWT.NULL);
		this.parent = parent;
		setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		this.setLayout(new GridLayout(1, true));
		
		expressionDisplay = new Composite(this, SWT.NONE); 
		expressionDisplay.setLayout(new RowLayout());
		expressionDisplay.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		expressionDisplay.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		slider = new Slider(this, SWT.HORIZONTAL);
	    slider.addListener(SWT.Selection, this);
	    slider.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
	    
	    defaultBackground = parent.getBackground();
	}
	
	private void setSlider(int max)
	{
		slider.setThumb(1);
		slider.setMinimum(0);
		slider.setPageIncrement(1);
		slider.setIncrement(1);
		slider.setMaximum(max);
	}
	
	public void setFeatureEquation(Equation equation, IProject project, IWorkbenchPage page)
	{
		this.equation = equation;
		this.project = project;
		this.page = page;
		
		// Dispose existing labels
		if(labels != null)
		{
			for(int i = 0; i < labels.length; i++)
			{
				labels[i].dispose();
			}
		}		
		
		// Add a label for each feature
		labels = new Label[equation.getIncrementalFeatures().size()];
		for(int i = equation.getIncrementalFeatures().size()-1; i >= 0; i--)
		{
			labels[i] = new Label(expressionDisplay, SWT.NULL);
			labels[i].setText(equation.toStringIncrementalFeature
					(equation.getIncrementalFeatures().get(i), project));
			System.out.println(i + ": " + labels[i].getText());
			labels[i].redraw();
		}
		
		// Set slider value
		setSlider(equation.getIncrementalFeatures().size());
		
		// Redraw		
		expressionDisplay.pack(true);
		expressionDisplay.layout();
		this.pack(true);		
		this.parent.pack(true);
		expressionDisplay.redraw();		
		slider.redraw();
		this.redraw();
		this.parent.redraw();
	}	
	
	// Process incremental selection
	public void handleEvent(Event event)
	{			
		if(page != null)
		{
			int selectedIncrement = equation.getIncrementalFeatures().size()-1
									-slider.getSelection();
			
			// Color the selected features in the equation
			setSelection(selectedIncrement);
			
			// Go through each feature and make visible only those features up to
			// the selected increment
			for(int i = 0; i < equation.getIncrementalFeatures().size(); i++)
			{
				boolean visible = (i <= selectedIncrement)? true:false;			
				FeatureNameManager.
					getFeatureNameManager(project).
						setFeatureVisible(equation.getIncrementalFeatures().get(i).getFeature(), visible);						
			}			
			// Refresh editor
			page.activate(page.getActiveEditor());
		}								              
    }
	
	// Label position left to right from N-1...0
	protected void setSelection(int labelPosition)
	{
		for(int i = 0; i < equation.getIncrementalFeatures().size(); i++)
		{
			if(i <= labelPosition)
				labels[i].setBackground(SELECTED_BACKGROUND);
			else
				labels[i].setBackground(defaultBackground);
		}		
		this.redraw();
	}

}
