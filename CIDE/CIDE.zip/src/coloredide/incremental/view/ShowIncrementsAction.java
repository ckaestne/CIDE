package coloredide.incremental.view;

import java.util.List;
import java.util.Vector;

import org.eclipse.jface.action.Action;

import coloredide.features.Feature;
import coloredide.features.FeatureManager;
import coloredide.features.source.IColoredJavaSourceFile;
import coloredide.incremental.Delta;
import coloredide.incremental.Visitor;

public class ShowIncrementsAction extends Action
{
	private IColoredJavaSourceFile sourceFile;

	public ShowIncrementsAction(IColoredJavaSourceFile sourceFile) {
		this.setText("Show increments");						
		this.sourceFile = sourceFile;
	}
	
	@Override
	public void run()
	{						
				
		//printEquation(tree);
	}
		
	
	
	private void printDelta(Delta root)
	{
		System.out.println("Delta tree:");
		root.accept(new Visitor()
		{
			public boolean visit(Delta d)
			{
				System.out.println(d.toString(sourceFile.getProject()));
				return true;
			}		
		});
	}
}
