package coloredide.incremental;

import java.util.LinkedHashSet;
import java.util.Set;

import coloredide.features.Feature;


public class IncrementalFeature
{
	public static final String BASE = "0";
	
	// Feature symbol 
	protected Feature feature;
	
	// Dependencies to other features.  The features that this feature changes
	// This information is used to determine desirable feature orderings.
	// Therefore, it has to be independent of a particular feature ordering, or Equation
	protected Set<IncrementalFeature> dependencies = new LinkedHashSet<IncrementalFeature>();	

	public Feature getFeature() {
		return feature;
	}

	public void setFeature(Feature feature) {
		this.feature = feature;
	}

	public Set<IncrementalFeature> getDependencies()
	{
		return dependencies; 
	}
}
