package coloredide.incremental;

import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import org.eclipse.core.resources.IProject;

import coloredide.features.Feature;

public class Equation
{
	protected List<IncrementalFeature> incrementalFeatures = new Vector<IncrementalFeature>();
	
	// The reason features-to-deltas mapping is in Equation and not in IncrementalFeature is that
	// deltas of a feature are specific to a particular ordering of features, i.e., an equation
	protected Dictionary<IncrementalFeature, List<Delta>> featuresToDeltas = new Hashtable<IncrementalFeature, List<Delta>>(); 
	
	public List<IncrementalFeature> getIncrementalFeatures()
	{
		return incrementalFeatures;
	}
		
	
	public Dictionary<IncrementalFeature, List<Delta>> getFeaturesToDeltas() {
		return featuresToDeltas;
	}

	public void addDeltaToFeature(Delta delta, IncrementalFeature incFeature)
	{
		List<Delta> deltas = featuresToDeltas.get(incFeature);
		if(deltas == null)
		{
			deltas = new Vector<Delta>();
			featuresToDeltas.put(incFeature, deltas);
		}
		deltas.add(delta);		
	}

	/**
	 * Returns the string representation of this feature equation given the project,
	 * up to the feature specified by limit, and a flag indicating whether the deltas
	 * should be shown or not.
	 * @param project
	 * @param limit
	 * @param showDeltas
	 * @return
	 */
	public String toString(IProject project, int limit, boolean showDeltas)
	{
		String str = "";
		for(int i = limit; i >= 0; i--)
		{
			if(showDeltas)
				str += toStringIncrementalFeature
						(incrementalFeatures.get(i), project) + " ";
			else
			{
				String featureName = IncrementalFeature.BASE;
				Feature f = incrementalFeatures.get(i).getFeature();
				if(f != null)
					featureName = f.getShortName(project);
				str += featureName + " * ";
			}
		}

		return str;
	}
	
	public String toStringIncrementalFeature(IncrementalFeature incrementalFeature, IProject project)
	{
		String featureName = IncrementalFeature.BASE;
		if(incrementalFeature.getFeature() != null)
			featureName = incrementalFeature.getFeature().getShortName(project);
		
		String str = "[" + featureName + "]\n{"; 
		List<Delta> deltas = featuresToDeltas.get(incrementalFeature);
		if(deltas != null)
		{
			for(int i = deltas.size()-1; i >= 0; i--)
			{
				str += "(" + deltas.get(i).toString(project) + ")";
			}
		}
				
		str += "}";
				
		return str;
	}
}
