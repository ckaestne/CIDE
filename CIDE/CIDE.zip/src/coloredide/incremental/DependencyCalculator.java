package coloredide.incremental;

import java.util.List;

import coloredide.features.Feature;

/**
 * This class is used to return 
 * @author chpkim
 *
 */
public class DependencyCalculator implements Visitor
{
	public static DependencyCalculator INSTANCE = new DependencyCalculator();
	
	// This has to be cleaned up for later -> we can either construct the IncrementalFeatures
	// from the Delta tree or we can pass it in.  For now, we pass it in because the delta tree
	// may not have some of the top level features.
	protected List<IncrementalFeature> incFeatures;
	
	public void calculateDependencies(List<IncrementalFeature> incFeatures, Delta root)
	{
		this.incFeatures = incFeatures;		
		root.accept(this);
	}
	
	public boolean visit(Delta d)
	{
		IncrementalFeature incFeature = getIncFeatureFor(d.getFeature());
		Delta currentDelta = d.getParent();
	
		// Go through each parent up to the root and add
		// the dependency
		while(currentDelta != null)
		{
			IncrementalFeature affectedIncFeature = 
				getIncFeatureFor(currentDelta.getFeature());
			incFeature.getDependencies().add(affectedIncFeature);
			
			currentDelta = currentDelta.getParent();
		}
		
		// TODO Auto-generated method stub
		return true;
	}
	
	// From the list of incremental features, get the incremental feature that wraps
	// the given Feature (color).
	private IncrementalFeature getIncFeatureFor(Feature feature)
	{
		IncrementalFeature foundIncFeature = null;
		
		for(IncrementalFeature incFeature: incFeatures)
		{
			if((incFeature.getFeature() != null && feature != null &&
					incFeature.getFeature().compareTo(feature) == 0) ||
				(incFeature.getFeature() == null && feature == null))
			{
				foundIncFeature = incFeature;
				break;
			}
		}
		
		return foundIncFeature;
	}
}
