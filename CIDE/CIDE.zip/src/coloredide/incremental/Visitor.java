package coloredide.incremental;

public interface Visitor
{
	public boolean visit(Delta d);
}
