package coloredide.incremental;

import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Vector;

import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.core.dom.ASTNode;

import coloredide.features.Feature;

public class Delta implements Visitable
{
	// A list of AST nodes could have the same derivative
	protected List<ASTNode> nodes = new Vector<ASTNode>();	
	
	// Recursive structure.  For quick access, 
	// children are accessible by their names.
	// Path is computed automatically.  The top node has no nodes, but has children.	
	protected Dictionary<Feature, Delta> children = new Hashtable<Feature, Delta>();
	protected Delta parent;
	
	protected Feature feature;
		
	/**
	 * Returns the list of deltas from this Delta to the root Delta 
	 * @param project
	 * @return
	 */
	public List<Delta> getPath()
	{		
		List<Delta> path = new Vector<Delta>();
		Delta d = this;
		while(d != null)
		{
			path.add(d);
			d = d.getParent();
		}		
		return path;
	}	

	public Delta getParent() {
		return parent;
	}

	public void setParent(Delta parent) {
		this.parent = parent;
	}

	public List<ASTNode> getNodes() {
		return nodes;
	}

	public Dictionary<Feature, Delta> getChildren() {
		return children;
	}

	public void setFeature(Feature feature)
	{
		this.feature = feature;
	}

	public Feature getFeature() {
		return feature;
	}

	/**
	 * Depth-First Traversal
	 */
	public void accept(Visitor visitor)
	{
		if(visitor.visit(this))
		{
			Enumeration<Delta> deltas = children.elements();
			while(deltas.hasMoreElements())
			{
				deltas.nextElement().accept(visitor);
			}			
		}	
	}
	
	/**
	 * Breadth-First Traversal
	 */
	public void acceptBFT(Visitor visitor)
	{
		Queue<Delta> queue = new LinkedList<Delta>();
		queue.add(this);
		while(!queue.isEmpty())
		{
			// Dequeue
			Delta d = queue.remove();
			
			// Enqueue children
			Enumeration<Delta> children = d.getChildren().elements();
			while(children.hasMoreElements())			
				queue.add(children.nextElement());			
			
			// Visit
			visitor.visit(d);			
		}
	}
		
	public String toString(IProject project)
	{
		String str = "";
		List<Delta> path = getPath();
		for(Delta d: path)
		{
			Feature f = d.getFeature();
			if(f != null)
				str += f.getShortName(project) + "\\"; 
			else
				str += IncrementalFeature.BASE;
		}
		return str;
	}	
}
