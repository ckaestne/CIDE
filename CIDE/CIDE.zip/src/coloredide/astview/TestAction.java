package coloredide.astview;

import org.eclipse.jface.action.Action;

public class TestAction extends Action  {
public TestAction(){
	this.setText("test");
}
@Override
public void run() {
//	IEditorPart editorPart = EditorUtility.getActiveEditor();
//	JavaEditor javaEditor = (JavaEditor)editorPart;
//	javaEditor.getSourceViewerConfiguration();
}
}
